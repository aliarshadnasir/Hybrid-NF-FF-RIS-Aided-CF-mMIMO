clear all 
clc

N=4;
Nbr=8000;
S11=randn(N,N)+1i*randn(N,N);
S12=randn(N,N)+1i*randn(N,N);
S21=randn(N,N)+1i*randn(N,N);
S22=randn(N,N)+1i*randn(N,N);

u1=randn(N,1)+1i*randn(N,1);
u2=randn(N,1)+1i*randn(N,1);


w1=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
w2=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));

g1=u1+S11*w1+S12*w2;
g2=u2+S21*w1+S22*w2;


R1=0;
for n=1:Nbr
    R1=R1+abs(g1(:,n)'*g2(:,n))^2/Nbr;
end
EX1 = abs(u1'*u2)^2;
EX2 = u1'*(S21*S21'+S22*S22')*u1;
EX3 = u2'*(S11*S11'+S12*S12')*u2;
EX4 = 2*real(u1'*u2*(trace(S21'*S11)+trace(S22'*S12)));
EX5 = trace((S11*S11'+S12*S12')*(S21*S21'+S22*S22'));
EX6 = abs(trace(S11'*S21)+trace(S12'*S22))^2;

R2 = EX1+EX2+EX3+EX4+EX5+EX6;
