function [H_rl,h_kr_LS_origin,beta_kr,beta_kr_LS,h_kr_NLS,h_kl,R_kr,R_kl,eta_kr] = CSIGenerate(lambda,Aperture_RIS,Aperture_AP,L,K,Na,Naz,Nr,Nrz,APpositions,RISposition,UEpositions,D_kr,nbrOfRealization)
%Generate large scale fading coefficients, azimuth and elevation angles

%INPUT:
%L                        = Number of APs in the cell-free network
%Na                       = Number of antennas per AP
%OUTPUT:
%h_kr_LS_origin           = Channel from UE to RIS; Size: Nr*K
%% Generate basic parameters
%Number of Scatters
Ns=4;

%Central Array Height of UE, AP and RIS
Height_UE = 1.65+lambda/2;
Height_AP = 10+Height_UE+Naz/2*lambda/2;
Height_RIS = 15+Height_UE+Nrz/2*lambda/2;
Height_Scatter = 2;

%Antenna Gain of AP, Element Gain of XL-HRIS
G_AP = 5;
G_RIS = 5;

%Generate distances, large scale fading coefficients, azimuth and elevation angles
d_kl = zeros(L,K);
beta_kl = zeros(L,K);
theta_kl = zeros(L,K);%azimuth angles
phi_kl = zeros(L,K);%elevation angles

for ii = 1:K
    d_kl(:,ii) = sqrt(abs(UEpositions(ii)-APpositions).^2+(Height_UE-Height_AP)^2);%Distance from the central point of UE to the central point of AP
    beta_kl(:,ii) = db2pow(G_AP-33.05-36.7*log10(d_kl(:,ii)));
    theta_kl(:,ii) = acos((real(UEpositions(ii))-real(APpositions))./abs(UEpositions(ii)-APpositions));
    phi_kl(:,ii) = acos((Height_UE-Height_AP)./d_kl(:,ii));
end

d_kr = sqrt(abs(UEpositions-RISposition).^2+(Height_UE-Height_RIS)^2);%Distance from the central point of UE to the central point of XL-RIS; size: K*1
beta_kr = db2pow(G_RIS-33.05-30*log10(d_kr));%size: K*1
theta_kr = acos((real(UEpositions)-real(RISposition))./abs(UEpositions-RISposition));%size: K*1
phi_kr = acos((Height_UE-Height_RIS)./d_kr);%size: K*1

d_rl = sqrt(abs(RISposition-APpositions).^2+(Height_RIS-Height_AP)^2);%Distance from the central point of XL-RIS to the central point of AP
beta_rl = db2pow(G_AP+G_RIS-35.9-22*log10(d_rl));%size: L*1
theta_rl = acos((real(RISposition)-real(APpositions))./abs(RISposition-APpositions));%size: L*1
phi_rl = acos((Height_RIS-Height_AP)./d_rl);%size: L*1
%% Generate channels of UE->RIS, RIS->AP, and UE->AP

%Generate NF-FF indicator functions
%eta_kl = ones(L,K);
eta_rl = ones(L,1);
eta_kr = ones(K,1);%Can be used as the Indicator for NF-(eta_kr==1) and FF-UE(eta_kr==0)
eta_sl = ones(Ns,1);

%Generate Rician factor
kappa_rl = ones(L,1);
kappa_kr = ones(K,1);

%Generate indexes
Nax = Na/Naz;
Nrx = Nr/Nrz;
bar_Nax = (Nax-1)/2; bar_Naz = (Naz-1)/2;
bar_Nrx = (Nrx-1)/2; bar_Nrz = (Nrz-1)/2;
bar_nax = (-bar_Nax:1:bar_Nax)'; bar_naz = (-bar_Naz:1:bar_Naz)';
bar_nrx = -(-bar_Nrx:1:bar_Nrx)'; bar_nrz = -(-bar_Nrz:1:bar_Nrz)';

%Prepare to save results
H_rl = zeros(Na,Nr,L);
H_rl_NLoS  = zeros(Na,Nr,L);
h_kr_LS_origin = zeros(Nr,K);
h_kr_NLS = zeros(Nr,nbrOfRealization,K);
%h_kl = zeros(Na,L,K);
h_kl = zeros(Na,nbrOfRealization,L,K);

R_kr = zeros(Nr,Nr,K);
R_kl = zeros(Na,Na,L,K);

%Generate H_rl
for l = 1:L
    if d_rl(l)<2*(Aperture_RIS+Aperture_AP)^2/lambda
        kappa_rl(l) = 10e6;
        eta_rl(l) = 1;
    else
        kappa_rl(l) = db2pow(13-0.03*d_rl(l));
        eta_rl(l) = 0;
    end

    %LoS path
    alx = exp(-1i*2*pi/lambda*(-bar_nax*lambda/2*cos(theta_rl(l))*sin(phi_rl(l))+eta_rl(l)/(2*d_rl(l))*bar_nax.^2*lambda^2/4*(1-cos(theta_rl(l))^2*sin(phi_rl(l))^2)));%size: Nax*1
    alz = exp(-1i*2*pi/lambda*(-bar_naz*lambda/2*cos(phi_rl(l))+eta_rl(l)/(2*d_rl(l))*bar_naz.^2*lambda^2/4*sin(phi_rl(l))^2));%size: Naz*1
    arx = exp(-1i*2*pi/lambda*(-bar_nrx*lambda/2*cos(theta_rl(l))*sin(phi_rl(l))+eta_rl(l)/(2*d_rl(l))*bar_nrx.^2*lambda^2/4*(1-cos(theta_rl(l))^2*sin(phi_rl(l))^2)));%size: Nrx*1
    arz = exp(-1i*2*pi/lambda*(-bar_nrz*lambda/2*cos(phi_rl(l))+eta_rl(l)/(2*d_rl(l))*bar_nrz.^2*lambda^2/4*sin(phi_rl(l))^2));%size: Nrz*1
    al = kron(alx,alz);%size: Na*1
    ar = kron(arx,arz);%size: Nr*1
    
    H_rlx = exp(-1i*2*pi/lambda*eta_rl(l)/d_rl(l)*repmat(bar_naz,[1,Nrz]).*repmat(bar_nrz.',[Naz,1])*lambda^2/4*(1-cos(theta_rl(l))^2*sin(phi_rl(l))^2));%size: Naz*Nrz;
    H_rlz = exp(-1i*2*pi/lambda*eta_rl(l)/d_rl(l)*repmat(bar_nax,[1,Nrx]).*repmat(bar_nrx.',[Nax,1])*lambda^2/4*sin(phi_rl(l))^2);%size: Nax*Nrx;
    beta_rl_LS = kappa_rl(l)*beta_rl(l)/(kappa_rl(l)+1);
    H_rl(:,:,l) = beta_rl_LS^0.5*exp(-1i*2*pi/lambda*d_rl(l))*(al*ar.').*kron(H_rlx,H_rlz);
    
    %NLoS path
    step = conj(RISposition-APpositions(l))/(3*Ns);%3*Ns is the scaling factor
    Index_Scatter = -Ns/2:1:Ns/2;
    Index_Scatter(Ns/2+1) = [];
    Scatterpositions = (step*Index_Scatter+0.5*(RISposition+APpositions(l))).';
    
    d_sl = sqrt(abs(Scatterpositions-APpositions(l)).^2+(Height_Scatter-Height_AP)^2);
    theta_sl = acos((real(Scatterpositions)-real(APpositions(l)))./abs(Scatterpositions-APpositions(l)));
    phi_sl = acos((Height_Scatter-Height_AP)./d_sl);
 
    d_rs = sqrt(abs(RISposition-Scatterpositions).^2+(Height_RIS-Height_Scatter)^2);%Distance from the central point of XL-RIS to the scatter
    theta_rs = acos((real(RISposition)-real(Scatterpositions))./abs(RISposition-Scatterpositions));%size: L*1
    phi_rs = acos((Height_RIS-Height_Scatter)./d_rs);

    beta_rl_NLS = beta_rl(l)/(kappa_rl(l)+1);
    %bar_alpha_s = sqrt(0.5)*(randn(Ns,1)+1i*randn(Ns,1));%Generate random attenuation for scatters
    bar_alpha_s = ones(Ns,1);
    for s = 1:Ns
        if d_rs(s)<2*Aperture_RIS^2/lambda
            eta_rs = 1;
        else
            eta_rs = 0;
        end
        alx = exp(-1i*2*pi/lambda*(-bar_nax*lambda/2*cos(theta_sl(s))*sin(phi_sl(s))+eta_sl(s)/(2*d_sl(s))*bar_nax.^2*lambda^2/4*(1-cos(theta_sl(s))^2*sin(phi_sl(s))^2)));%size: Nax*1
        alz = exp(-1i*2*pi/lambda*(-bar_naz*lambda/2*cos(phi_sl(s))+eta_sl(s)/(2*d_sl(s))*bar_naz.^2*lambda^2/4*sin(phi_sl(s))^2));%size: Naz*1
        arx = exp(-1i*2*pi/lambda*(-bar_nrx*lambda/2*cos(theta_rs(s))*sin(phi_rs(s))+eta_rs/(2*d_rs(s))*bar_nrx.^2*lambda^2/4*(1-cos(theta_rs(s))^2*sin(phi_rs(s))^2)));%size: Nrx*1
        arz = exp(-1i*2*pi/lambda*(-bar_nrz*lambda/2*cos(phi_rs(s))+eta_rs/(2*d_rs(s))*bar_nrz.^2*lambda^2/4*sin(phi_rs(s))^2));%size: Nrz*1
        al = kron(alx,alz);%size: Na*1
        ar = kron(arx,arz);%size: Nr*1
        H_rl_NLoS(:,:,l) = H_rl_NLoS(:,:,l)+(beta_rl_NLS/Ns)^0.5*bar_alpha_s(s)*exp(-1i*2*pi/lambda*(d_rs(s)+d_sl(s)))*(al*ar.');
    end
    H_rl(:,:,l) = H_rl(:,:,l)+H_rl_NLoS(:,:,l);
end

%Rearrange the value order
bar_nrx = (-bar_Nrx:1:bar_Nrx)'; bar_nrz = (-bar_Nrz:1:bar_Nrz)';

%Generate h_kr
beta_kr_LS = zeros(K,1);
for k = 1:K
    if d_kr(k)<2*Aperture_RIS^2/lambda
        kappa_kr(k) = 10e6;
        eta_kr(k) = 1;
    else
        kappa_kr(k) = db2pow(13-0.03*d_kr(k));
        eta_kr(k) = 0;
    end
    %LoS path
    beta_kr_LS(k) = kappa_kr(k)*beta_kr(k)/(kappa_kr(k)+1);
    arx = exp(-1i*2*pi/lambda*(-bar_nrx*lambda/2*cos(theta_kr(k))*sin(phi_kr(k))+eta_kr(k)/(2*d_kr(k))*bar_nrx.^2*lambda^2/4*(1-cos(theta_kr(k))^2*sin(phi_kr(k))^2)));%size: Nrx*1
    arz = exp(-1i*2*pi/lambda*(-bar_nrz*lambda/2*cos(phi_kr(k))+eta_kr(k)/(2*d_kr(k))*bar_nrz.^2*lambda^2/4*sin(phi_kr(k))^2));%size: Nrz*1
    ar = kron(arx,arz);%size: Nr*1
    h_kr_LS_origin(:,k) = beta_kr_LS(k)^0.5*exp(-1i*2*pi/lambda*d_kr(k))*diag(D_kr(k))*ar;

    if eta_kr(k)==0%FF-UE
        %NLoS path
        step = conj(UEpositions(k)-RISposition)/(3*Ns);%3*Ns is the scaling factor
        Index_Scatter = -Ns/2:1:Ns/2;
        Index_Scatter(Ns/2+1) = [];
        Scatterpositions = (step*Index_Scatter+0.5*(UEpositions(k)+RISposition)).';

        d_sr = sqrt(abs(Scatterpositions-RISposition).^2+(Height_Scatter-Height_RIS)^2);
        theta_sr = acos((real(Scatterpositions)-real(RISposition))./abs(Scatterpositions-RISposition));
        phi_sr = acos((Height_Scatter-Height_RIS)./d_sr);

        %     d_ks = sqrt(abs(UEpositions(k)-Scatterpositions).^2+(Height_UE-Height_Scatter)^2);%Distance from the central point of XL-RIS to the scatter
        %     theta_ks = acos((real(UEpositions(k))-real(Scatterpositions))./abs(UEpositions(k)-Scatterpositions));%size: L*1
        %     phi_ks = acos((Height_UE-Height_Scatter)./d_ks);

        beta_kr_NLS = beta_kr(k)/(kappa_kr(k)+1);
        for s = 1:Ns
            if d_sr(s)<2*Aperture_RIS^2/lambda
                eta_sr = 1;
            else
                eta_sr = 0;
            end
            arx = exp(-1i*2*pi/lambda*(-bar_nrx*lambda/2*cos(theta_sr(s))*sin(phi_sr(s))+eta_sr/(2*d_sr(s))*bar_nrx.^2*lambda^2/4*(1-cos(theta_sr(s))^2*sin(phi_sr(s))^2)));%size: Nrx*1
            arz = exp(-1i*2*pi/lambda*(-bar_nrz*lambda/2*cos(phi_sr(s))+eta_sr/(2*d_sr(s))*bar_nrz.^2*lambda^2/4*sin(phi_sr(s))^2));%size: Nrz*1
            ar = kron(arx,arz);%size: Nr*1
            R_kr(:,:,k) = R_kr(:,:,k)+beta_kr_NLS/Ns*(ar*ar');
        end
        %h_kr(:,:,k) = repmat(h_kr_LS_origin(:,k),[1,nbrOfRealization])+R_kr(:,:,k)^0.5*sqrt(0.5)*(randn(Nr,nbrOfRealization)+1i*randn(Nr,nbrOfRealization));
        h_kr_NLS(:,:,k) = R_kr(:,:,k)^0.5*sqrt(0.5)*(randn(Nr,nbrOfRealization)+1i*randn(Nr,nbrOfRealization));
    end


end

%Generate h_kl

for k =1:K
    for l = 1:L
        %LoS path
        %alx = exp(-1i*2*pi/lambda*(-bar_nax*lambda/2*cos(theta_kl(l,k))*sin(phi_kl(l,k))+eta_kl(l,k)/(2*d_kl(l,k))*bar_nax.^2*lambda^2/4*(1-cos(theta_kl(l,k))^2*sin(phi_kl(l,k))^2)));%size: Nax*1
        %alz = exp(-1i*2*pi/lambda*(-bar_naz*lambda/2*cos(phi_kl(l,k))+eta_kl(l,k)/(2*d_kl(l,k))*bar_naz.^2*lambda^2/4*sin(phi_kl(l,k))^2));%size: Naz*1
        %al = kron(alx,alz);%size: Na*1
        %h_kl(:,l,k) = beta_kl(l,k)^0.5*exp(-1i*2*pi/lambda*d_kl(l,k))*al;
        
        %NLoS path
        step = conj(UEpositions(k)-APpositions(l))/(3*Ns);%3*Ns is the scaling factor
        Index_Scatter = -Ns/2:1:Ns/2;
        Index_Scatter(Ns/2+1) = [];
        Scatterpositions = (step*Index_Scatter+0.5*(UEpositions(k)+APpositions(l))).';

        d_sl = sqrt(abs(Scatterpositions-APpositions(l)).^2+(Height_Scatter-Height_AP)^2);
        theta_sl = acos((real(Scatterpositions)-real(APpositions(l)))./abs(Scatterpositions-APpositions(l)));
        phi_sl = acos((Height_Scatter-Height_AP)./d_sl);
        for s = 1:Ns
            alx = exp(-1i*2*pi/lambda*(-bar_nax*lambda/2*cos(theta_sl(s))*sin(phi_sl(s))+eta_sl(s)/(2*d_sl(s))*bar_nax.^2*lambda^2/4*(1-cos(theta_sl(s))^2*sin(phi_sl(s))^2)));%size: Nax*1
            alz = exp(-1i*2*pi/lambda*(-bar_naz*lambda/2*cos(phi_sl(s))+eta_sl(s)/(2*d_sl(s))*bar_naz.^2*lambda^2/4*sin(phi_sl(s))^2));%size: Naz*1
            al = kron(alx,alz);%size: Na*1
            R_kl(:,:,l,k) = R_kl(:,:,l,k)+beta_kl(l,k)/Ns*(al*al');
        end
        h_kl(:,:,l,k) = R_kl(:,:,l,k)^0.5*sqrt(0.5)*(randn(Na,nbrOfRealization)+1i*randn(Na,nbrOfRealization));
    end
end

%%Comparison with the General Channel model
% Generate Coordinates of AP and RIS
% 
% AP0_XZ_Coordinate = lambda/2*reshape((repmat(bar_nax.',[Naz,1])+1i*repmat(bar_naz,[1,Nax])),[],1);
% RIS0_XZ_Coordinate = lambda/2*reshape((repmat(bar_nrx.',[Nrz,1])+1i*repmat(bar_nrz,[1,Nrx])),[],1);
% 
% RIS_XYZ_Coordinate = [real(RISposition)+real(RIS0_XZ_Coordinate),imag(RISposition)+zeros(Nr,1),imag(RIS0_XZ_Coordinate)+Height_RIS];%size: Nr*3
% 
% H_rl2 = zeros(Na,Nr,L);
% bar_h_kr2 = zeros(Nr,K);
% h_kl2 = zeros(Na,L,K);
% 
% for l = 1:L
%     APl_XYZ_Coordinate = [real(APpositions(l))+real(AP0_XZ_Coordinate),imag(APpositions(l))+zeros(Na,1),imag(AP0_XZ_Coordinate)+Height_AP];%size: Na*3
%     for n1 = 1:Na
%         for n2 = 1:Nr
%             H_rl2(n1,n2,l) = beta_rl(l)^0.5*exp(-1i*2*pi/lambda*norm(APl_XYZ_Coordinate(n1,:)-RIS_XYZ_Coordinate(n2,:)));
%         end
%     end
% end
% 
% for k = 1:K
%     UEk_XYZ_Coordinate=[real(UEpositions(k)),imag(UEpositions(k)),Height_UE];%Size: 1*3
%     for n = 1:Nr
%         bar_h_kr2(n,k) = beta_kr(k)^0.5*exp(-1i*2*pi/lambda*norm(UEk_XYZ_Coordinate-RIS_XYZ_Coordinate(n,:)));
%     end
% end
% 
% for k =1:K
%     UEk_XYZ_Coordinate=[real(UEpositions(k)),imag(UEpositions(k)),Height_UE];%Size: 1*3
%     for l = 1:L
%         APl_XYZ_Coordinate = [real(APpositions(l))+real(AP0_XZ_Coordinate),imag(APpositions(l))+zeros(Na,1),imag(AP0_XZ_Coordinate)+Height_AP];
%         for n = 1:Na
%             h_kl2(n,l,k) = beta_kl(l)^0.5*exp(-1i*2*pi/lambda*norm(UEk_XYZ_Coordinate-APl_XYZ_Coordinate(n,:)));
%         end
%     end
% end
