clear all
clc 
nbrOfRealizations=20000;


ur=3;ui=6;
lambda=ur^2+ui^2;
sigma_squared=8*10^-1;
xi=(lambda+sigma_squared+sigma_squared)/2;
Xr=ur+sqrt(sigma_squared)*randn(1,nbrOfRealizations);
Xi=ui+sqrt(sigma_squared)*randn(1,nbrOfRealizations);

%Non-central chi-squared distribution
Y=Xr.^2+Xi.^2;
R_sim=sum(Y<xi)/nbrOfRealizations;

[fy1,y1]=ksdensity(Y);
y2=0:1:150;
fy2=1/(2*sigma_squared).*exp(-(y2+lambda)/(2*sigma_squared)).*besseli(0,sqrt(y2*lambda)/sigma_squared);

hold on
box on
p1=plot(y1,fy1,'--sr');
p2=plot(y2,fy2,'--ob');
legend([p1 p2],{'Simulation','Analysis (Eq. (21))'});


fun=@(z)1/(2*sigma_squared).*exp(-(z+lambda)/(2*sigma_squared)).*besseli(0,sqrt(z*lambda)/sigma_squared);
R_ana1=integral(@(z)fun(z),0,xi);
R_ana2=1-marcumq(sqrt(lambda/sigma_squared),sqrt(xi/sigma_squared));

