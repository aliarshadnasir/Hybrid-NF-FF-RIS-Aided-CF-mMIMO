clear all 
clc

N=4;
Nbr=8000;

hat_gkl_LS=randn(N,1)+1i*randn(N,1);
gil_LS=randn(N,1)+1i*randn(N,1);

Akl=randn(N,N)+1i*randn(N,N);
Bkl=randn(N,N)+1i*randn(N,N);
Ajl=randn(N,N)+1i*randn(N,N);
Bjl=randn(N,N)+1i*randn(N,N);
Aql=randn(N,N)+1i*randn(N,N);
Bql=randn(N,N)+1i*randn(N,N);
Ail=randn(N,N)+1i*randn(N,N);
Bil=randn(N,N)+1i*randn(N,N);


wa_kl=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wb_kr=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wa_ql=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wb_qr=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wa_il=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wb_ir=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));



bar_gkl=Akl*wa_kl+Bkl*wb_kr;
bar_gql=Aql*wa_ql+Bql*wb_qr;
bar_gjl=Ajl*wa_il+Bjl*wb_ir;%i\in{P}_k
gil=gil_LS+Ail*wa_il+Bil*wb_ir;
v=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));


R=0;T1=0;T2=0;T3=0;T4=0;
T5=0;T6=0;
T7=0;
for n=1:Nbr
    R=R+abs((hat_gkl_LS+bar_gkl(:,n)+bar_gjl(:,n)+bar_gql(:,n)+v(:,n))'*gil(:,n))^2/Nbr;
    T1=T1+abs(hat_gkl_LS'*gil(:,n))^2/Nbr;
    T2=T2+abs(bar_gkl(:,n)'*gil(:,n))^2/Nbr;
    T3=T3+abs(bar_gjl(:,n)'*gil(:,n))^2/Nbr;
    T4=T4+abs(v(:,n)'*gil(:,n))^2/Nbr;
    T5=T5+hat_gkl_LS'*gil(:,n)*gil(:,n)'*bar_gjl(:,n)/Nbr;
    T6=T6+bar_gjl(:,n)'*gil(:,n)*gil(:,n)'*hat_gkl_LS/Nbr;
    T7=T7+abs(bar_gql(:,n)'*gil(:,n))^2/Nbr;
    
end
T=T1+T2+T3+T4+T5+T6+T7;
