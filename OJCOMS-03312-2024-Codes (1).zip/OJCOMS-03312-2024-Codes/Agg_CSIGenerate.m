function [g_kl_LS,hat_g_kl_LS,g_kl,hat_g_kl,Brl,bar_A_kl,bar_B_kl,dot_Phi_ltk] = Agg_CSIGenerate(Pilot_index,tau,H_rl,h_kr_LS,hat_h_kr_LS,h_kr_NLS,h_kl,R_kr,R_kl,eta_kr,L,K,Na,Nr,BN_RF,p,sigma_squared,Theta,Pinv_Theta_RF,rho,nbrOfRealization)
%INPUT:
%h_kr_LS           = Channel from UE to RIS; size: Nr*K;
%h_kr_NLS          = Channel from UE to RIS; size: Nr*nbrOfRealization*K;
%h_kl              = Channel from UE to AP; size: Na*nbrOfRealization*L*K;
%R_kr              = Covariance matrix from UE to RIS; Size: Nr*Nr*K;
%R_kl              = Covariance matrix from UE to AP; Size: Na*Na*L*K;

%Prepare to save results

g_kl_LS = zeros(Na,L,K);
g_kl_NLS = zeros(Na,nbrOfRealization,L,K);
g_kl = zeros(Na,nbrOfRealization,L,K);


bar_A_kl = zeros(Na,Na,L,K);
bar_B_kl = zeros(Na,Nr,L,K);
dot_Phi_ltk = zeros(Na,Na,L,K);

hat_g_kl_LS = zeros(Na,L,K);
hat_g_kl_NLS = zeros(Na,nbrOfRealization,L,K);
hat_g_kl = zeros(Na,nbrOfRealization,L,K);


%% Generate basic parameters

%Generate tilde_h_kr_LS
tilde_h_kr_LS = h_kr_LS-hat_h_kr_LS;
%Generage random noise vectors
nl_tk = sqrt(sigma_squared/2)*(randn(Na,nbrOfRealization,L,tau)+1i*randn(Na,nbrOfRealization,L,tau));
%Generate Brl
Brl = zeros(Na,Nr,L);
for k = 1:K
    for l = 1:L
        Brl(:,:,l) = rho*H_rl(:,:,l)*Theta;
        g_kl_LS(:,l,k) = Brl(:,:,l)*h_kr_LS(:,k);
%         A1 = h_kl(:,:,l,k);
%         A2 = Brl(:,:,l)*h_kr_NLS(:,:,k);
        g_kl_NLS(:,:,l,k) = h_kl(:,:,l,k)+Brl(:,:,l)*h_kr_NLS(:,:,k);
        g_kl(:,:,l,k) = repmat(g_kl_LS(:,l,k),[1,nbrOfRealization])+g_kl_NLS(:,:,l,k);
    end
end

%% Generate the aggregated channel both for the accurate and estiamted version

for k = 1:K
    t_k = Pilot_index(k);
    Pilot_tk_UE_index = find(t_k==Pilot_index)';
    for l = 1:L
  
        %
        bar_R_kl = R_kl(:,:,l,k)+Brl(:,:,l)*R_kr(:,:,k)*Brl(:,:,l)';
        bar_Phi_ltk = sigma_squared*eye(Na);
        dot_Phi_ltk(:,:,l,k) = sigma_squared*eye(Na);
        %
        tilde_g_kl_VLS = Brl(:,:,l)*tilde_h_kr_LS(:,k);
        sum_tilde_gjl_VLS = 0;
        for j1 = Pilot_tk_UE_index
 
            %
            tilde_g_j1l_VLS = Brl(:,:,l)*tilde_h_kr_LS(:,j1);
            bar_R_kl = bar_R_kl+sqrt(p(j1)/p(k))*tilde_g_kl_VLS*tilde_g_j1l_VLS';
            bar_Phi_ltk = bar_Phi_ltk+tau*p(j1)*(R_kl(:,:,l,j1)+Brl(:,:,l)*R_kr(:,:,j1)*Brl(:,:,l)');
            dot_Phi_ltk(:,:,l,k) = dot_Phi_ltk(:,:,l,k)+tau*p(j1)*(R_kl(:,:,l,j1)+Brl(:,:,l)*R_kr(:,:,j1)*Brl(:,:,l)');
            for j2 = Pilot_tk_UE_index
                tilde_g_j2l_VLS = Brl(:,:,l)*tilde_h_kr_LS(:,j2);
                bar_Phi_ltk = bar_Phi_ltk+tau*sqrt(p(j1)*p(j2))*tilde_g_j1l_VLS*tilde_g_j2l_VLS';
            end
            sum_tilde_gjl_VLS = sum_tilde_gjl_VLS+sqrt(tau*p(j1))*tilde_g_j1l_VLS;
            %
        end
        %
        bar_A_kl(:,:,l,k) = sqrt(tau*p(k))*bar_R_kl*bar_Phi_ltk^-1;%Eq.(48)
        bar_B_kl(:,:,l,k) = bar_A_kl(:,:,l,k)*Brl(:,:,l);
        hat_g_kl_NLS(:,:,l,k) = bar_A_kl(:,:,l,k)*nl_tk(:,:,l,t_k);
        for j1 = Pilot_tk_UE_index
            hat_g_kl_NLS(:,:,l,k) = hat_g_kl_NLS(:,:,l,k)+sqrt(tau*p(j1))*(bar_A_kl(:,:,l,k)*h_kl(:,:,l,j1)+bar_B_kl(:,:,l,k)*h_kr_NLS(:,:,j1));
        end

        hat_g_kl_VLS = Brl(:,:,l)*hat_h_kr_LS(:,k);
        hat_g_kl_LS(:,l,k) = hat_g_kl_VLS+sqrt(tau*p(k))*bar_R_kl*bar_Phi_ltk^-1*sum_tilde_gjl_VLS;
        hat_g_kl(:,:,l,k) = repmat(hat_g_kl_LS(:,l,k),[1,nbrOfRealization])+hat_g_kl_NLS(:,:,l,k);
    end
end











