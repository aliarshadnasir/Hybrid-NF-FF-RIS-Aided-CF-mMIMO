function [E_sim,E_ana,F_sim,F_ana] = Theorem1_test(eta_kr,g_kl_LS,hat_g_kl_LS,g_kl,hat_g_kl,R_kr,R_kl,Brl,bar_A_kl,bar_B_kl,Pilot_index,tau,K,Na,BN_RF,p,sigma_squared,nbrOfRealization)
%INPUT:
%g_kl_LS               = Los Channel from UE to APsize: Na*L*K;
%g_kl                  = Channel from UE to AP; size: Na*nbrOfRealization*L*K;
%hat_g_kl              = Estimated Channel from UE to AP; size: Na*nbrOfRealization*L*K;
%R_kr                  = Covariance matrix from UE to RIS; Size: Nr*Nr*K;
%R_kl                  = Covariance matrix from UE to AP; Size: Na*Na*L*K;
%Brl                   = Matrix with size: Na*Nr*L;
%bar_A_kl              = Matrix with size: Na*Na*L*K;
%bar_B_kl              = Matrix with size: Na,Nr*L*K;

II=circshift(1:K,1);
l1 = 4; l2 = 5;
E_sim = zeros(K,1);
E_ana = zeros(K,1);%Eqs. (61) and (62)
F_sim = zeros(K,1);
F_ana = zeros(K,1);%Eqs. (63) and (64)
k = 1;
    %ii = II(k);%ii not in P_k
    
    %ii = k;%ii in P_k
    t_k = Pilot_index(k);
    Pilot_tk_UE_index = find(t_k==Pilot_index)';
    ii = setdiff(Pilot_tk_UE_index,k);
    


    V_rl_tk = sigma_squared*bar_A_kl(:,:,l1,k)*bar_A_kl(:,:,l1,k)'+sigma_squared/BN_RF*bar_B_kl(:,:,l1,k)*bar_B_kl(:,:,l1,k)';
    V_r_tk = sigma_squared/BN_RF*bar_B_kl(:,:,l1,k)*bar_B_kl(:,:,l1,k)';
    %l1==l2
    %E_sim(k) = trace(abs((hat_g_kl(:,:,l1,k)'*g_kl(:,:,l1,ii)).*eye(nbrOfRealization)).^2)/nbrOfRealization;
    E_sim(k) = sum(abs(sum(conj(hat_g_kl(:,:,l1,k)).*g_kl(:,:,l1,ii),1)).^2,2)/nbrOfRealization;
    E_ana(k) = trace((g_kl_LS(:,l1,ii)*g_kl_LS(:,l1,ii)'+R_kl(:,:,l1,ii)+Brl(:,:,l1)*R_kr(:,:,ii)*Brl(:,:,l1)')*(hat_g_kl_LS(:,l1,k)*hat_g_kl_LS(:,l1,k)'+V_rl_tk));
    for jj = Pilot_tk_UE_index
        if jj~=ii
        E_ana(k) = E_ana(k)+tau*p(jj)*trace((g_kl_LS(:,l1,ii)*g_kl_LS(:,l1,ii)'+R_kl(:,:,l1,ii)+Brl(:,:,l1)*R_kr(:,:,ii)*Brl(:,:,l1)')*(bar_A_kl(:,:,l1,k)*R_kl(:,:,l1,jj)*bar_A_kl(:,:,l1,k)'+bar_B_kl(:,:,l1,k)*R_kr(:,:,jj)*bar_B_kl(:,:,l1,k)'));
        else
            S11 = bar_A_kl(:,:,l1,k)*R_kl(:,:,l1,ii)^0.5;
        S21 = R_kl(:,:,l1,ii)^0.5;
        S12 = bar_B_kl(:,:,l1,k)*R_kr(:,:,ii)^0.5;
        S22 = Brl(:,:,l1)*R_kr(:,:,ii)^0.5;
        Es = Lemma1(zeros(Na,1),g_kl_LS(:,l1,ii),S11,S21,S12,S22);
        E_ana(k) = E_ana(k)+tau*p(ii)*Es;
       end
    end
    if ismember(ii,Pilot_tk_UE_index)
         E_ana(k) = E_ana(k)+sqrt(tau*p(ii))*2*real(hat_g_kl_LS(:,l1,k)'*g_kl_LS(:,l1,ii)*trace(bar_A_kl(:,:,l1,k)*R_kl(:,:,l1,ii)+bar_B_kl(:,:,l1,k)*R_kr(:,:,ii)*Brl(:,:,l1)'));
    end

    %l1~=l2
    %F_sim(k) = trace(((hat_g_kl(:,:,l1,k)'*g_kl(:,:,l1,ii)).*eye(nbrOfRealization))*((g_kl(:,:,l2,ii)'*hat_g_kl(:,:,l2,k)).*eye(nbrOfRealization)))/nbrOfRealization;
    F_sim(k) = sum(sum(conj(hat_g_kl(:,:,l1,k)).*g_kl(:,:,l1,ii),1).*sum(conj(g_kl(:,:,l2,ii)).*hat_g_kl(:,:,l2,k),1),2)/nbrOfRealization;
    F_ana(k) = trace((g_kl_LS(:,l1,ii)*g_kl_LS(:,l2,ii)'+Brl(:,:,l1)*R_kr(:,:,ii)*Brl(:,:,l2)')*(hat_g_kl_LS(:,l2,k)*hat_g_kl_LS(:,l1,k)'+V_r_tk));
    for jj = Pilot_tk_UE_index
        if jj~=ii
            F_ana(k) = F_ana(k)+tau*p(jj)*trace((g_kl_LS(:,l1,ii)*g_kl_LS(:,l2,ii)'+Brl(:,:,l1)*R_kr(:,:,ii)*Brl(:,:,l2)')*bar_B_kl(:,:,l2,k)*R_kr(:,:,jj)*bar_B_kl(:,:,l1,k)');
        else
            S11l1 = bar_A_kl(:,:,l1,k)*R_kl(:,:,l1,ii)^0.5;
            S21l1 = R_kl(:,:,l1,ii)^0.5;
            S12l1 = bar_B_kl(:,:,l1,k)*R_kr(:,:,ii)^0.5;
            S22l1 = Brl(:,:,l1)*R_kr(:,:,ii)^0.5;
            S11l2 = bar_A_kl(:,:,l2,k)*R_kl(:,:,l2,ii)^0.5;
            S21l2 = R_kl(:,:,l2,ii)^0.5;
            S12l2 = bar_B_kl(:,:,l2,k)*R_kr(:,:,ii)^0.5;
            S22l2 = Brl(:,:,l2)*R_kr(:,:,ii)^0.5;
            Ec = Lemma2(zeros(Na,1),g_kl_LS(:,l1,ii),zeros(Na,1),g_kl_LS(:,l2,ii),S11l1,S21l1,S12l1,S22l1,S11l2,S21l2,S12l2,S22l2);
            F_ana(k) = F_ana(k)+tau*p(ii)*Ec;
        end
    end
    if ismember(ii,Pilot_tk_UE_index)
        F_ana(k) = F_ana(k)+sqrt(tau*p(ii))*(hat_g_kl_LS(:,l1,k)'*g_kl_LS(:,l1,ii)*trace(bar_A_kl(:,:,l2,k)*R_kl(:,:,l2,ii)+bar_B_kl(:,:,l2,k)*R_kr(:,:,ii)*Brl(:,:,l2)')...
                +g_kl_LS(:,l2,ii)'*hat_g_kl_LS(:,l2,k)*trace(R_kl(:,:,l1,ii)*bar_A_kl(:,:,l1,k)'+Brl(:,:,l1)*R_kr(:,:,ii)*bar_B_kl(:,:,l1,k)'));  
    end
    A=0;