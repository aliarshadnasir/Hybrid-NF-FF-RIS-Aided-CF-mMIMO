function Pilot_index = Pilot_Assignment(tau,H_rl,h_kr_LS,beta_kr,R_kr,R_kl,L,K,NF_UE_points,FF_UE_points,FF_UE_Index,Na,p,Theta,rho)
%INPUT:
%h_kr_LS           = Channel from UE to RIS; size: Nr*K;
%h_kr_NLS          = Channel from UE to RIS; size: Nr*nbrOfRealization*K;
%h_kl              = Channel from UE to AP; size: Na*nbrOfRealization*L*K;
%R_kr              = Covariance matrix from UE to RIS; Size: Nr*Nr*K;
%R_kl              = Covariance matrix from UE to AP; Size: Na*Na*L*K;

%Prepare to save results

bar_beta_kl = zeros(L,K);

%% Generate basic parameters
for k = 1:K
    for l = 1:L
        Brl = rho*H_rl(:,:,l)*Theta;
        g_kl_LS = Brl*h_kr_LS(:,k);
        bar_beta_kl(l,k) = trace(g_kl_LS*g_kl_LS'+R_kl(:,:,l,k)+Brl*R_kr(:,:,k)*Brl')/Na;
    end
end

%Initialization of the pilot indexes
Pilot_index_NF_UE = (1:NF_UE_points)';
Pilot_index_FF_UE = zeros(FF_UE_points,1);
Pilot_index = [Pilot_index_NF_UE;Pilot_index_FF_UE];
%Sorting FF_UE_Index by beta_kr from largest to smallest
for ii= 1:FF_UE_points-1
    for jj = NF_UE_points+1:K-ii
        if beta_kr(jj) < beta_kr(jj+1)

           beta_temp = beta_kr(jj+1);
           beta_kr(jj+1) = beta_kr(jj);
           beta_kr(jj) = beta_temp;

           UE_temp = FF_UE_Index(jj-NF_UE_points+1);
           FF_UE_Index(jj-NF_UE_points+1) = FF_UE_Index(jj-NF_UE_points);
           FF_UE_Index(jj-NF_UE_points) = UE_temp;
        end
    end
end
%FF-UE pilot allocation
for k = FF_UE_Index
    if k<=tau
        Pilot_index(k) = k;
    else
        [~,l_km] = max(bar_beta_kl(:,k));
        Pilot_contamination = zeros(tau,1);
        for t = 1:tau
            Pilot_t_UE_index = find(t==Pilot_index)';
            for jj = Pilot_t_UE_index
                Pilot_contamination(t) = Pilot_contamination(t)+p(jj)*bar_beta_kl(l_km,jj);
            end
        end
        [~,t_k] = min(Pilot_contamination);
        Pilot_index(k) = t_k;
    end
end