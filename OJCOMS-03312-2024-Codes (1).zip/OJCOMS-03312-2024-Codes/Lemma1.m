function Es = Lemma1(u1,u2,S11,S21,S12,S22)

EX1 = abs(u1'*u2)^2;
EX2 = u1'*(S21*S21'+S22*S22')*u1;
EX3 = u2'*(S11*S11'+S12*S12')*u2;
EX4 = 2*real(u1'*u2*(trace(S21'*S11)+trace(S22'*S12)));
EX5 = trace((S11*S11'+S12*S12')*(S21*S21'+S22*S22'));
EX6 = abs(trace(S11'*S21)+trace(S12'*S22))^2;

Es = EX1+EX2+EX3+EX4+EX5+EX6;


