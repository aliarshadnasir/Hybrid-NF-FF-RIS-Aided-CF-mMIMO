function [R_ana,partial_R_ana] = Theorem2_AP_Cooperation(AP_UE_selection,F_sim,F_ana,varrho_kl_sim,varrho_kl_ana,c_kl_sim,c_kl_ana,p,K,fraction)


R_ana = zeros(K,1);
partial_R_ana = zeros(K,1);
for k = 1:K
    C_ana = diag(varrho_kl_ana(:,k))-p(k)*c_kl_ana(:,k)*c_kl_ana(:,k)';
    %
    partial_dimension = sum(AP_UE_selection(:,k));

    select_varrho_kl_ana = varrho_kl_ana(:,k).*AP_UE_selection(:,k);
    partial_varrho_kl_ana = select_varrho_kl_ana(select_varrho_kl_ana~=0);

    select_c_kl_ana = c_kl_ana(:,k).*AP_UE_selection(:,k);
    partial_c_kl_ana = select_c_kl_ana(AP_UE_selection(:,k)~=0);

    partial_C_ana = diag(partial_varrho_kl_ana)-p(k)*(partial_c_kl_ana*partial_c_kl_ana');
    
    for ii = 1:K
        C_ana = C_ana+p(ii)*F_ana(:,:,k,ii);
        %
        select_F_ana = F_ana(:,:,k,ii).*(AP_UE_selection(:,k)*AP_UE_selection(:,k)');
        non_zero_elements = select_F_ana(AP_UE_selection(:,k)*AP_UE_selection(:,k)'~=0);
        partial_F_ana = reshape(non_zero_elements,partial_dimension,partial_dimension);

        partial_C_ana = partial_C_ana+p(ii)*partial_F_ana;

    end
    R_ana(k) = fraction*log2(1+p(k)*c_kl_ana(:,k)'*C_ana^-1*c_kl_ana(:,k));
    partial_R_ana(k) = fraction*log2(1+p(k)*partial_c_kl_ana'*partial_C_ana^-1*partial_c_kl_ana);
end
