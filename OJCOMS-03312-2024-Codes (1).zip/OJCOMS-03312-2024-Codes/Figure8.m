%This Matlab script generates Figures 3 in the paper
%"Hybrid-Near/Far Field Communications of XL-RIS Aided Cell-Free Massive MIMO with Visibility Regions"
%%
clear all
clc

%System Parameters Setting
c = 3*10^8; %the speed of light
f = 28*10^9; %carrier frequency
lambda = c/f; %wavelength
Length = 100; %length of the cell

T = 200;%Length of the coherence block (T>B*tau)
tau_v = 8;%Length of the pilot
tau = 10;
nu = 0.8;
VR_FF = 0;%1: FF-UEs transmit pilot during VR detection; 0: FF-UEs don't transmit pilot during VR detection

L = 36; %Number of APs in the cell-free network
K = 20; %Number of UEs in the cell-free network
NF_UE_points = 8;
FF_UE_points = K-NF_UE_points;

Nax = 1; Naz = [1 3 5 7 9];
Na = Nax*Naz; %Number of antennas per AP
Nrx_origin = 93; Nrz_origin = 3; %Number of elements of XL-RIS in X and Z directions
Nrx = 3; Nrz = 3; %Number of elements of XL-RIS in X and Z directions
Nr = Nrx*Nrz; %Number of elements of XL-RIS (Integer multiple of 3)
BN_RF = Nr+10;%Total number of RF chains over B time blocks
B=5;

D_kr = ones(Nr,K);%Initialization of VR
nbrSubRIS = 3;
SubRIS_index = round(1 + (nbrSubRIS-1)*rand(1,K));%Each subRIS contains three columns

p0 = 100*ones(1,K);%Uplink transmit power per UE in [mW]
sigma_squared = db2pow(-96);%Channel Noise power in [dBm] (Default -96dBm)
nbrOfRealization = 5;%Number of RV realization including noise and channel

%Central Array Height of UE, AP and RIS
Height_UE = 1.65+lambda/2;
Height_RIS = 15+Height_UE+Nrz/2*lambda/2;
Aperture_RIS = sqrt(Nrx_origin^2+Nrz_origin^2)*lambda/2; %Array aperture of XL-RIS
Rayleigh_distance_RIS = 2*Aperture_RIS^2/lambda;%Rayleigh distance of XL-RIS
NF_Radius = sqrt(Rayleigh_distance_RIS^2-(Height_UE-Height_RIS)^2);

Aperture_AP = sqrt(Nax.^2+Naz.^2)*lambda/2; %Array aperture of AP

[APpositions,RISposition,UEpositions] = Position_Generate_Determin(NF_UE_points,FF_UE_points,L,Length,NF_Radius);
epsilon = [0 0.01 0.1 1];
for ii = 1:length(epsilon)
    for n = 1:length(Na)
        disp(['Step' num2str(n) ' out of ' num2str(length(Na))]);
        fraction = (T-tau)/T;
        %CSI generate
        [H_rl,h_kr_LS_origin,beta_kr,beta_kr_LS,h_kr_NLS,h_kl,R_kr,R_kl,eta_kr] = CSIGenerate(lambda,Aperture_RIS,Aperture_AP(n),L,K,Na(n),Naz(n),Nr,Nrz,APpositions,RISposition,UEpositions,D_kr,nbrOfRealization);
        %Identify for NF-UE(eta_kr==1) and FF-UE(eta_kr==0)
        NF_UE_Index = find(eta_kr==1)';
        FF_UE_Index = find(eta_kr==0)';

        %% From now on we consider the NF UE
        %Update VR and h_kr_LS for NF-UE
        h_kr_LS = h_kr_LS_origin;

        for k = NF_UE_Index
            D_kr(:,k) = 1;
            D_kr((SubRIS_index(k)-1)*Nr/3+1:SubRIS_index(k)*Nr/3,k) = 0;
            h_kr_LS(:,k) = D_kr(:,k).*h_kr_LS(:,k);
        end

        %Parameters of HRIS
        Theta_RF = exp(1i*2*pi/BN_RF*(0:BN_RF-1)'*(randperm(Nr)-1));
        Test1 = Theta_RF'*Theta_RF;%Identity matrix verification
        Pinv_Theta_RF=(Theta_RF'*Theta_RF)^-1*Theta_RF';
        Test2 = Pinv_Theta_RF*Pinv_Theta_RF'*BN_RF;%Identity matrix verification

        Theta = diag(exp(-1i*zeros(Nr,1)));
        rho = 1;

        %Allocate UEs' the pilot sequences during VR detection
        Pilot_index = Pilot_Assignment(tau_v,H_rl,h_kr_LS,beta_kr,R_kr,R_kl,L,K,NF_UE_points,FF_UE_points,FF_UE_Index,Na(n),p0,Theta,rho);
        %Set threshold
        sigma_tk_squared = zeros(1,K);
        sum_h_kr_LS = zeros(Nr,K);
        sum_h_kr_LS_no_UEk = zeros(Nr,K);
        for k = 1:K
            t_k = Pilot_index(k);
            dot_Phi_rtk = sigma_squared/BN_RF*eye(Nr);
            Pilot_tk_UE_index = find(t_k==Pilot_index)';
            for jj = Pilot_tk_UE_index
                sum_h_kr_LS(:,k) = sum_h_kr_LS(:,k)+sqrt(tau_v*p0(jj))*h_kr_LS_origin(:,jj);
                if  ismember(jj,FF_UE_Index) %FF-UE
                    dot_Phi_rtk = dot_Phi_rtk+tau_v*p0(jj)*R_kr(:,:,jj);%Eq.(25)
                    sum_h_kr_LS_no_UEk(:,k) = sum_h_kr_LS_no_UEk(:,k)+sqrt(tau_v*p0(jj))*h_kr_LS_origin(:,jj);
                end
            end
            sigma_tk_squared(k) = dot_Phi_rtk(1,1);
        end
        epsilon_kn = 0.5*(abs(sum_h_kr_LS).^2+repmat(sigma_tk_squared,Nr,1)+abs(sum_h_kr_LS_no_UEk).^2+repmat(sigma_tk_squared,Nr,1));%Size: Nr*K

        %VR detection
        [hat_D_kr,Prob_zero_ana(:,:),Prob_zero_sim(:,:),Prob_one_ana(:,:),Prob_one_sim(:,:)] = VREstimate(VR_FF,D_kr,h_kr_LS,h_kr_NLS,NF_UE_Index,Pilot_index,tau_v,K,Nr,BN_RF,p0,sigma_squared,nbrOfRealization,Pinv_Theta_RF,epsilon_kn,sigma_tk_squared);%Size of hat_D_kr: Nr*nbrOfRealization*K

        %Generate hat_h_kr_LS for NF-UE
        hat_h_kr_LS = h_kr_LS_origin;
        for k = NF_UE_Index
            hat_h_kr_LS(:,k) = hat_D_kr(:,k).*hat_h_kr_LS(:,k);
        end

        %Allocate UEs' the pilot sequences during CSI estimation
        [Pilot_index,AP_UE_selection,bar_beta_kl,p] = AP_Cooperation_Pilot_Assignment(nu,epsilon(ii),tau,H_rl,h_kr_LS,beta_kr,R_kr,R_kl,L,K,NF_UE_points,FF_UE_points,FF_UE_Index,Na(n),p0,Theta,rho);
  
        %Generate Aggregated CSI
        [g_kl_LS,hat_g_kl_LS,g_kl,hat_g_kl,Brl,bar_A_kl,bar_B_kl,dot_Phi_ltk] = Agg_CSIGenerate(Pilot_index,tau,H_rl,h_kr_LS,hat_h_kr_LS,h_kr_NLS,h_kl,R_kr,R_kl,eta_kr,L,K,Na(n),Nr,BN_RF,p,sigma_squared,Theta,Pinv_Theta_RF,rho,nbrOfRealization);
        [F_sim,F_ana,varrho_kl_sim,varrho_kl_ana,c_kl_sim,c_kl_ana] = Theorem1(g_kl_LS,hat_g_kl_LS,g_kl,hat_g_kl,R_kr,R_kl,Brl,bar_A_kl,bar_B_kl,dot_Phi_ltk,eta_kr,Pilot_index,tau,K,L,Na(n),BN_RF,p,sigma_squared,nbrOfRealization);
        [~,R_ana(:,n,ii)] = Theorem2_AP_Cooperation(AP_UE_selection,F_sim,F_ana,varrho_kl_sim,varrho_kl_ana,c_kl_sim,c_kl_ana,p,K,fraction);
    end
    Selection_matrix(:,:,ii) = AP_UE_selection;
end
%% Plot simulation results
figureUnits = 'centimeters';
figureWidth = 20;
figureHeight = 8;

figure(1)
hold on; box on;
fp1 = plot(Na,real(sum(R_ana(:,:,1),1)),'+-','Color','#D00000','LineWidth',2);
fp2 = plot(Na,real(sum(R_ana(:,:,2),1)),'+-','Color','#15821E','LineWidth',2);
fp3 = plot(Na,real(sum(R_ana(:,:,3),1)),'+-b','LineWidth',2);
fp4 = plot(Na,real(sum(R_ana(:,:,4),1)),'+-k','LineWidth',2);
xlabel('Number of AP antennas');
ylabel('Sum SE [bit/s/Hz]');
legend([fp1 fp2 fp3 fp4],{'Full connection (\epsilon=0)','Partial connection (\epsilon=0.01)','Partial connection (\epsilon=0.1)','Small cell (\epsilon=1)'});
set(gcf,'Units',figureUnits,'Position',[0 0 figureWidth figureHeight],'Color','w');

%discussion:
a1 = real(sum(R_ana(:,:,1),1));
a2 = real(sum(R_ana(:,:,2),1));
SE_ratio = a2(end)/a1(end);

Connection_ratio = sum(Selection_matrix(:,:,2),'all')/(L*K);

figure(2)
A_noZero = Selection_matrix(:,:,2)';
A_noZero(A_noZero == 0) = NaN;
h = bar3(A_noZero);
view(0, 90);

for k = 1:length(h)
    % Get the ZData of each column
    Zdata = get(h(k), 'ZData'); 
    % Initialize color data
    CData = ones(size(Zdata)); % Default color index is 1 (non-zero columns)
    % Mark the portion of ZData that is 0 as color index 2 (white)
    CData(Zdata == 0) = 2; 
    % Setting color data
    set(h(k), 'CData', CData, 'FaceColor', 'flat'); 
end
% Custom color mapping: index 1 is green, index 2 is white
colormap([hex2rgb('#15821E'); 1 1 1]); % RGB values for green and white

xlabel('AP index'); ylabel('UE index'); 
ylim([0,K+1])
set(gcf,'Units',figureUnits,'Position',[0 0 figureWidth figureHeight],'Color','w');