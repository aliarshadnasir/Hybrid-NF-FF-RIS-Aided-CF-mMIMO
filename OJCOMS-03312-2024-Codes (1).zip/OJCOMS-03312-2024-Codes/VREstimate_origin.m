function [hat_D_kr,Ave_Prob_zero_ana,Ave_Prob_zero_ana_pure,Ave_Prob_zero_sim,Ave_Prob_one_ana,Ave_Prob_one_ana_pure,Ave_Prob_one_sim] = VREstimate_origin(D_kr,h_kr_LS_origin,h_kr_LS,beta_kr_LS,h_kr_NLS,R_kr,NF_UE_Index,FF_UE_Index,Pilot_index,tau,K,Nr,BN_RF,p,sigma_squared,nbrOfRealization,Pinv_Theta_RF)
%INPUT:
%Nr                = Number of elements of RIS
%h_kr_LS           = Channel from UE to RIS; size: Nr*K
%D_kr              = Realistic VR of UEs; size: Nr*K
%OUTPUT:
%hat_D_kr          = Estimated VR of UEs; size: Nr*K
%% Generate basic parameters

%Generate h_kr
h_kr = zeros(Nr,nbrOfRealization,K);
for  k = 1:K
     h_kr(:,:,k) = repmat(h_kr_LS(:,k),[1,nbrOfRealization])+h_kr_NLS(:,:,k);
end

%Generate nr_tk
nr_tk = sqrt(sigma_squared/2)*(randn(BN_RF,nbrOfRealization,tau)+1i*randn(BN_RF,nbrOfRealization,tau));
sigma_tk_squared = zeros(1,K);
for k = 1:K
    t_k = Pilot_index(k);
    dot_Phi_rtk = sigma_squared/BN_RF*eye(Nr);
    Pilot_tk_UE_index = find(t_k==Pilot_index)';
    for jj = Pilot_tk_UE_index
        if  ismember(jj,FF_UE_Index) %FF-UE
            dot_Phi_rtk = dot_Phi_rtk+tau*p(jj)*R_kr(:,:,jj);%Eq.(25)
        end
    end
    sigma_tk_squared(k) = dot_Phi_rtk(1,1);
end

%Set threshold

epsilon = 0.5*(tau*p.*abs(h_kr_LS_origin(1,:)).^2+sigma_tk_squared+sigma_tk_squared);%Size: 1*K
epsilon2 = zeros(1,K);
%% Prepare to save results

%Initialization of the estimated VR
hat_D_kr_ergodic = ones(Nr,nbrOfRealization,K);
hat_D_kr = ones(Nr,K);

%Initialization of Miss Detection Probability (Wrontly estimated as zero) 
Prob_zero_ana = zeros(Nr,length(NF_UE_Index));
Prob_zero_ana_pure = zeros(Nr,length(NF_UE_Index));
Prob_zero_sim = zeros(Nr,length(NF_UE_Index));

%Initialization of False Alarm Probability (Wrontly estimated as one) 
Prob_one_ana = zeros(Nr,length(NF_UE_Index));
Prob_one_ana_pure = zeros(Nr,length(NF_UE_Index));
Prob_one_sim = zeros(Nr,length(NF_UE_Index));

Length_zero = zeros(1,length(NF_UE_Index));
Length_one = zeros(1,length(NF_UE_Index));

for k = NF_UE_Index%Note: NF-UE only has the LoS path concering RIS
    %z_rtk = sqrt(tau*p(k))*repmat(h_kr_LS(:,k),[1,nbrOfRealization])+Pinv_Theta_RF*nr_tk(:,:,Pilot_index(k));%Received pilot signal of RIS; Eq.(25)
    z_rtk = Pinv_Theta_RF*nr_tk(:,:,Pilot_index(k));
    t_k = Pilot_index(k);
    Pilot_tk_UE_index = find(t_k==Pilot_index)';
    for jj = Pilot_tk_UE_index
        z_rtk = z_rtk+sqrt(tau*p(jj))*h_kr(:,:,jj);
        epsilon2(k) = epsilon2(k)+sqrt(tau*p(jj))*h_kr_LS_origin(1,jj);
    end
    epsilon2(k) = abs(epsilon2(k))^2;
    hat_D_kr_ergodic(:,:,k) = ~(abs(z_rtk).^2<epsilon(k));
    
    Index1 = find(D_kr(:,k) == 1);
    Length_zero(k) = length(Index1);
    Index0 = find(D_kr(:,k) == 0);
    Length_one(k) = length(Index0);
    %u_kn_squared1 = tau*p(k)*abs(h_kr_LS(Index1,k)).^2;
    u_kn1 = zeros(length(Index1),1);
    u_kn0 = zeros(length(Index0),1);
    for jj = Pilot_tk_UE_index
        u_kn1 = u_kn1+sqrt(tau*p(jj))*h_kr_LS(Index1,jj);
        u_kn0 = u_kn0+sqrt(tau*p(jj))*h_kr_LS(Index0,jj);
    end
    u_kn_squared1 = abs(u_kn1).^2;
    u_kn_squared0 = abs(u_kn0).^2;

    Prob_zero_ana(Index1,k) = 1-marcumq(sqrt(u_kn_squared1/(sigma_tk_squared(k)/2)),sqrt(epsilon(k)/(sigma_tk_squared(k)/2)));
    Prob_zero_ana_pure(Index1,k) = 1-marcumq(sqrt(tau*p(k)*beta_kr_LS(k)/(sigma_tk_squared(k)/2)),sqrt(epsilon(k)/(sigma_tk_squared(k)/2)));
    Prob_zero_sim(Index1,k) = sum(abs(z_rtk(Index1,:)).^2<epsilon(k),2)/nbrOfRealization;
    %Prob_one_ana(Index0,k) = exp(-epsilon(k)/sigma_tk_squared(k));
    Prob_one_ana(Index0,k) = marcumq(sqrt(u_kn_squared0/(sigma_tk_squared(k)/2)),sqrt(epsilon(k)/(sigma_tk_squared(k)/2)));
    Prob_one_ana_pure(Index0,k) = marcumq(0,sqrt(epsilon(k)/(sigma_tk_squared(k)/2)));
    Prob_one_sim(Index0,k) = sum(abs(z_rtk(Index0,:)).^2>=epsilon(k),2)/nbrOfRealization;
end

%Generate hat_D_kr from hat_D_kr_ergodic
for k = 1:K
    hat_D_kr(:,k) = hat_D_kr_ergodic(:,1,k);
end

%Compuatge Average Miss Detection Probability (size: 1*K)
Ave_Prob_zero_ana = sum(Prob_zero_ana)./Length_zero;%Equivalent with the validate element in "Prob_zero_ana"
Ave_Prob_zero_ana_pure = sum(Prob_zero_ana_pure)./Length_zero;
Ave_Prob_zero_sim = sum(Prob_zero_sim)./Length_zero;
%Compute Average False Alarm Probability (size: 1*K)
Ave_Prob_one_ana = sum(Prob_one_ana)./Length_one;%Equivalent with the validate element in "Prob_one_ana"
Ave_Prob_one_ana_pure = sum(Prob_one_ana_pure)./Length_one;
Ave_Prob_one_sim = sum(Prob_one_sim)./Length_one;
