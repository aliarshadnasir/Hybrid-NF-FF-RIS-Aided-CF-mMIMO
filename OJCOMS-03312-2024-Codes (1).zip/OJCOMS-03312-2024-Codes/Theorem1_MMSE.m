function [F_sim,varrho_kl_sim,c_kl_sim] = Theorem1_MMSE(g_kl,hat_g_kl,R_kr,R_kl,Brl,bar_A_kl,dot_Phi_ltk,K,L,Na,p,sigma_squared,nbrOfRealization)
%INPUT:
%g_kl_LS               = Los Channel from UE to APsize: Na*L*K;
%g_kl                  = Channel from UE to AP; size: Na*nbrOfRealization*L*K;
%hat_g_kl              = Estimated Channel from UE to AP; size: Na*nbrOfRealization*L*K;
%R_kr                  = Covariance matrix from UE to RIS; Size: Nr*Nr*K;
%R_kl                  = Covariance matrix from UE to AP; Size: Na*Na*L*K;
%Brl                   = Matrix with size: Na*Nr*L;
%bar_A_kl              = Matrix with size: Na*Na*L*K;
%bar_B_kl              = Matrix with size: Na,Nr*L*K;

V_MMSE = zeros(Na,nbrOfRealization,L,K);

for n = 1:nbrOfRealization
    for l = 1:L
        for k = 1:K
            V_MR = hat_g_kl(:,n,l,k);
            %Compute L-MMSE combining
            sum1 = sigma_squared*eye(Na);
            for v=1:K
                hat_R_kl = bar_A_kl(:,:,l,v)*dot_Phi_ltk(:,:,l,v)*bar_A_kl(:,:,l,v)';
                sum1=sum1+p(v)*(hat_g_kl(:,n,l,v)*hat_g_kl(:,n,l,v)'+R_kl(:,:,l,v)+Brl(:,:,l)*R_kr(:,:,v)*Brl(:,:,l)'-hat_R_kl);
            end
            V_MMSE(:,n,l,k)=sum1^-1*V_MR;
        end
    end
end


F_sim = zeros(L,L,K,K);
for k = 1:K
    for ii = 1:K
        for l1 = 1:L
            F_sim(l1,l1,k,ii) = sum(abs(sum(conj(V_MMSE(:,:,l1,k)).*g_kl(:,:,l1,ii),1)).^2,2)/nbrOfRealization;
            for l2 = setdiff(1:L,l1)
                F_sim(l1,l2,k,ii) = sum(sum(conj(V_MMSE(:,:,l1,k)).*g_kl(:,:,l1,ii),1).*sum(conj(g_kl(:,:,l2,ii)).*V_MMSE(:,:,l2,k),1),2)/nbrOfRealization;
            end
        end
    end
end

%% Generate other parameters
varrho_kl_sim = zeros(L,K);
c_kl_sim = zeros(L,K);

n_l = sqrt(sigma_squared/2)*(randn(Na,nbrOfRealization,L)+1i*randn(Na,nbrOfRealization,L));

for k = 1:K
    for l = 1:L
        varrho_kl_sim(l,k) = sum(abs(sum(conj(V_MMSE(:,:,l,k)).*n_l(:,:,l),1)).^2,2)/nbrOfRealization;
        c_kl_sim(l,k) = sum(conj(V_MMSE(:,:,l,k)).*g_kl(:,:,l,k),'all')/nbrOfRealization;
    end
end
