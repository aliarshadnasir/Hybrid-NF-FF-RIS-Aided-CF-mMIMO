function [F_sim,F_ana,varrho_kl_sim,varrho_kl_ana,c_kl_sim,c_kl_ana] = Theorem1(g_kl_LS,hat_g_kl_LS,g_kl,hat_g_kl,R_kr,R_kl,Brl,bar_A_kl,bar_B_kl,dot_Phi_ltk,eta_kr,Pilot_index,tau,K,L,Na,BN_RF,p,sigma_squared,nbrOfRealization)
%INPUT:
%g_kl_LS               = Los Channel from UE to APsize: Na*L*K;
%g_kl                  = Channel from UE to AP; size: Na*nbrOfRealization*L*K;
%hat_g_kl              = Estimated Channel from UE to AP; size: Na*nbrOfRealization*L*K;
%R_kr                  = Covariance matrix from UE to RIS; Size: Nr*Nr*K;
%R_kl                  = Covariance matrix from UE to AP; Size: Na*Na*L*K;
%Brl                   = Matrix with size: Na*Nr*L;
%bar_A_kl              = Matrix with size: Na*Na*L*K;
%bar_B_kl              = Matrix with size: Na,Nr*L*K;



F_sim = zeros(L,L,K,K);
F_ana = zeros(L,L,K,K);%Eqs. (61)-(64)
for k = 1:K
    t_k = Pilot_index(k);
    Pilot_tk_UE_index = find(t_k==Pilot_index)';
    for ii = 1:K
        for l1 = 1:L
            V_l_tk = sigma_squared*bar_A_kl(:,:,l1,k)*bar_A_kl(:,:,l1,k)';
            F_sim(l1,l1,k,ii) = sum(abs(sum(conj(hat_g_kl(:,:,l1,k)).*g_kl(:,:,l1,ii),1)).^2,2)/nbrOfRealization;
            F_ana(l1,l1,k,ii) = trace((g_kl_LS(:,l1,ii)*g_kl_LS(:,l1,ii)'+R_kl(:,:,l1,ii)+Brl(:,:,l1)*R_kr(:,:,ii)*Brl(:,:,l1)')*(hat_g_kl_LS(:,l1,k)*hat_g_kl_LS(:,l1,k)'+V_l_tk));
            for jj = Pilot_tk_UE_index
                if jj~=ii
                    F_ana(l1,l1,k,ii) = F_ana(l1,l1,k,ii)+tau*p(jj)*trace((g_kl_LS(:,l1,ii)*g_kl_LS(:,l1,ii)'+R_kl(:,:,l1,ii)+Brl(:,:,l1)*R_kr(:,:,ii)*Brl(:,:,l1)')*(bar_A_kl(:,:,l1,k)*R_kl(:,:,l1,jj)*bar_A_kl(:,:,l1,k)'+bar_B_kl(:,:,l1,k)*R_kr(:,:,jj)*bar_B_kl(:,:,l1,k)'));
                else
                    S11 = bar_A_kl(:,:,l1,k)*R_kl(:,:,l1,ii)^0.5;
                    S21 = R_kl(:,:,l1,ii)^0.5;
                    S12 = bar_B_kl(:,:,l1,k)*R_kr(:,:,ii)^0.5;
                    S22 = Brl(:,:,l1)*R_kr(:,:,ii)^0.5;
                    Es = Lemma1(zeros(Na,1),g_kl_LS(:,l1,ii),S11,S21,S12,S22);
                    F_ana(l1,l1,k,ii) = F_ana(l1,l1,k,ii)+tau*p(ii)*Es;
                end
            end
            if ismember(ii,Pilot_tk_UE_index)
                F_ana(l1,l1,k,ii) = F_ana(l1,l1,k,ii)+sqrt(tau*p(ii))*2*real(hat_g_kl_LS(:,l1,k)'*g_kl_LS(:,l1,ii)*trace(bar_A_kl(:,:,l1,k)*R_kl(:,:,l1,ii)+bar_B_kl(:,:,l1,k)*R_kr(:,:,ii)*Brl(:,:,l1)'));
            end
            for l2 = setdiff(1:L,l1)
                F_sim(l1,l2,k,ii) = sum(sum(conj(hat_g_kl(:,:,l1,k)).*g_kl(:,:,l1,ii),1).*sum(conj(g_kl(:,:,l2,ii)).*hat_g_kl(:,:,l2,k),1),2)/nbrOfRealization;
                F_ana(l1,l2,k,ii) = trace((g_kl_LS(:,l1,ii)*g_kl_LS(:,l2,ii)'+Brl(:,:,l1)*R_kr(:,:,ii)*Brl(:,:,l2)')*(hat_g_kl_LS(:,l2,k)*hat_g_kl_LS(:,l1,k)'));
                for jj = Pilot_tk_UE_index
                    if jj~=ii
                        F_ana(l1,l2,k,ii) = F_ana(l1,l2,k,ii)+tau*p(jj)*trace((g_kl_LS(:,l1,ii)*g_kl_LS(:,l2,ii)'+Brl(:,:,l1)*R_kr(:,:,ii)*Brl(:,:,l2)')*bar_B_kl(:,:,l2,k)*R_kr(:,:,jj)*bar_B_kl(:,:,l1,k)');
                    else
                        S11l1 = bar_A_kl(:,:,l1,k)*R_kl(:,:,l1,ii)^0.5;
                        S21l1 = R_kl(:,:,l1,ii)^0.5;
                        S12l1 = bar_B_kl(:,:,l1,k)*R_kr(:,:,ii)^0.5;
                        S22l1 = Brl(:,:,l1)*R_kr(:,:,ii)^0.5;
                        S11l2 = bar_A_kl(:,:,l2,k)*R_kl(:,:,l2,ii)^0.5;
                        S21l2 = R_kl(:,:,l2,ii)^0.5;
                        S12l2 = bar_B_kl(:,:,l2,k)*R_kr(:,:,ii)^0.5;
                        S22l2 = Brl(:,:,l2)*R_kr(:,:,ii)^0.5;
                        Ec = Lemma2(zeros(Na,1),g_kl_LS(:,l1,ii),zeros(Na,1),g_kl_LS(:,l2,ii),S11l1,S21l1,S12l1,S22l1,S11l2,S21l2,S12l2,S22l2);
                        F_ana(l1,l2,k,ii) = F_ana(l1,l2,k,ii)+tau*p(ii)*Ec;
                    end
                end
                if ismember(ii,Pilot_tk_UE_index)
                    F_ana(l1,l2,k,ii) = F_ana(l1,l2,k,ii)+sqrt(tau*p(ii))*(hat_g_kl_LS(:,l1,k)'*g_kl_LS(:,l1,ii)*trace(bar_A_kl(:,:,l2,k)*R_kl(:,:,l2,ii)+bar_B_kl(:,:,l2,k)*R_kr(:,:,ii)*Brl(:,:,l2)')...
                        +g_kl_LS(:,l2,ii)'*hat_g_kl_LS(:,l2,k)*trace(R_kl(:,:,l1,ii)*bar_A_kl(:,:,l1,k)'+Brl(:,:,l1)*R_kr(:,:,ii)*bar_B_kl(:,:,l1,k)'));
                end
            end
        end
    end
end

%% Generate other parameters
varrho_kl_sim = zeros(L,K);
varrho_kl_ana = zeros(L,K);
c_kl_sim = zeros(L,K);
c_kl_ana = zeros(L,K);

n_l = sqrt(sigma_squared/2)*(randn(Na,nbrOfRealization,L)+1i*randn(Na,nbrOfRealization,L));

for k = 1:K
    for l = 1:L
        varrho_kl_sim(l,k) = sum(abs(sum(conj(hat_g_kl(:,:,l,k)).*n_l(:,:,l),1)).^2,2)/nbrOfRealization;
        varrho_kl_ana(l,k) = sigma_squared*trace(hat_g_kl_LS(:,l,k)*hat_g_kl_LS(:,l,k)'+bar_A_kl(:,:,l,k)*dot_Phi_ltk(:,:,l,k)*bar_A_kl(:,:,l,k)');
        c_kl_sim(l,k) = sum(conj(hat_g_kl(:,:,l,k)).*g_kl(:,:,l,k),'all')/nbrOfRealization;
        c_kl_ana(l,k) = trace(g_kl_LS(:,l,k)*hat_g_kl_LS(:,l,k)'+sqrt(tau*p(k))*(R_kl(:,:,l,k)*bar_A_kl(:,:,l,k)'+Brl(:,:,l)*R_kr(:,:,k)*bar_B_kl(:,:,l,k)'));
    end
end
