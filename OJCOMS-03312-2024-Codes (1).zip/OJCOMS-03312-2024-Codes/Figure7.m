%This Matlab script generates Figures 3 in the paper
%"Hybrid-Near/Far Field Communications of XL-RIS Aided Cell-Free Massive MIMO with Visibility Regions"
%%
clear all
clc

%System Parameters Setting
c = 3*10^8; %the speed of light
f = 28*10^9; %carrier frequency
lambda = c/f; %wavelength
Length = [100 200 400 600 800]; %length of the cell
VR_FF = 0;%1: FF-UEs transmit pilot during VR detection; 0: FF-UEs don't transmit pilot during VR detection



L_origin = [25 36 49]; %Number of APs in the cell-free network
K = 20; %Number of UEs in the cell-free network
NF_UE_points = 8;
FF_UE_points = K-NF_UE_points;

Nax = 1; Naz = 3;
Na = Nax*Naz; %Number of antennas per AP
Nrx_origin = 93; Nrz_origin = 3; %Number of elements of XL-RIS in X and Z directions
Nrx = 3; Nrz = 3; %Number of elements of XL-RIS in X and Z directions
Nr = Nrx*Nrz; %Number of elements of XL-RIS (Integer multiple of 3)
BN_RF = Nr+10;%Total number of RF chains over B time blocks
B=5;

D_kr = ones(Nr,K);%Initialization of VR
nbrSubRIS = 3;
SubRIS_index = round(1 + (nbrSubRIS-1)*rand(1,K));%Each subRIS contains three columns

p = 100*ones(1,K);%Uplink transmit power per UE in [mW]
sigma_squared = db2pow(-96);%Channel Noise power in [dBm] (Default -96dBm)
nbrOfRealization = 5;%Number of RV realization including noise and channel

%Central Array Height of UE, AP and RIS
Height_UE = 1.65+lambda/2;
Height_RIS = 15+Height_UE+Nrz/2*lambda/2;
Aperture_RIS = sqrt(Nrx_origin^2+Nrz_origin^2)*lambda/2; %Array aperture of XL-RIS
Rayleigh_distance_RIS = 2*Aperture_RIS^2/lambda;%Rayleigh distance of XL-RIS
NF_Radius = sqrt(Rayleigh_distance_RIS^2-(Height_UE-Height_RIS)^2);

Aperture_AP = sqrt(Nax^2+Naz^2)*lambda/2; %Array aperture of AP

for l = 1:length(L_origin)
    for n = 1:length(Length)
        disp(['Setup ' num2str(n) ' out of ' num2str(length(Length))]);
        L = L_origin(l);
        Nax = 1; Naz = 3;
        Na = Nax*Naz; 
        [APpositions,RISposition,UEpositions] = Position_Generate_Determin(NF_UE_points,FF_UE_points,L,Length(n),NF_Radius);
        for ii = 1:2
            if ii == 2
                %MIMO setting
                APpositions = Length(n)/2+1i*Length(n)/2;
                L = 1;
                Na = Nax*Naz*L_origin(l);
                Nax = 3;
                Naz = Na/Nax;
            end
            %Show geometric locations of APs, XL-RIS, and UEs
            NF_region_X=Length(n)/2-Rayleigh_distance_RIS:0.001:Length(n)/2+Rayleigh_distance_RIS;
            NF_region_Y=Length(n)-sqrt(Rayleigh_distance_RIS^2-(NF_region_X-Length(n)/2).^2);
            % hold on
            % box on
            % scatter(real(APpositions),imag(APpositions),[],hex2rgb('DF2700'),'filled');
            % scatter(real(RISposition),imag(RISposition),[],[0 0 0],'filled');
            % scatter(real(UEpositions(1:NF_UE_points)),imag(UEpositions(1:NF_UE_points)),[],hex2rgb('1A15CA'),'filled');
            % scatter(real(UEpositions(NF_UE_points+1:K)),imag(UEpositions(NF_UE_points+1:K)),[],hex2rgb('24BB86'),'filled');
            % plot(NF_region_X,real(NF_region_Y),'Color','#1A15CA','LineWidth',2);
            % xlabel('X (m)');
            % ylabel('Y (m)');
            % legend('AP','XL-RIS','NF-UE','FF-UE','NF region')
            % set(gca, 'FontSize', 14)

            %CSI generate
            [H_rl,h_kr_LS_origin,beta_kr,beta_kr_LS,h_kr_NLS,h_kl,R_kr,R_kl,eta_kr] = CSIGenerate(lambda,Aperture_RIS,Aperture_AP,L,K,Na,Naz,Nr,Nrz,APpositions,RISposition,UEpositions,D_kr,nbrOfRealization);
            %Identify for NF-UE(eta_kr==1) and FF-UE(eta_kr==0)
            NF_UE_Index = find(eta_kr==1)';
            FF_UE_Index = find(eta_kr==0)';

            %% From now on we consider the NF UE
            %Update VR and h_kr_LS for NF-UE
            h_kr_LS = h_kr_LS_origin;

            for k = NF_UE_Index
                D_kr(:,k) = 1;
                D_kr((SubRIS_index(k)-1)*Nr/3+1:SubRIS_index(k)*Nr/3,k) = 0;
                h_kr_LS(:,k) = D_kr(:,k).*h_kr_LS(:,k);
            end

            %Parameters of HRIS
            Theta_RF = exp(1i*2*pi/BN_RF*(0:BN_RF-1)'*(randperm(Nr)-1));
            Test1 = Theta_RF'*Theta_RF;%Identity matrix verification
            Pinv_Theta_RF=(Theta_RF'*Theta_RF)^-1*Theta_RF';
            Test2 = Pinv_Theta_RF*Pinv_Theta_RF'*BN_RF;%Identity matrix verification

            Theta = diag(exp(-1i*zeros(Nr,1)));
            rho = 1;

            T = 200;%Length of the coherence block (T>B*tau)
            tau = 10;%Length of the pilot
            tau_d = T-B*tau;%Length of the data

            %Allocate UEs' the pilot sequences
            Pilot_index = Pilot_Assignment(tau,H_rl,h_kr_LS,beta_kr,R_kr,R_kl,L,K,NF_UE_points,FF_UE_points,FF_UE_Index,Na,p,Theta,rho);
            %Set threshold
            sigma_tk_squared = zeros(1,K);
            sum_h_kr_LS = zeros(Nr,K);
            sum_h_kr_LS_no_UEk = zeros(Nr,K);
            for k = 1:K
                t_k = Pilot_index(k);
                dot_Phi_rtk = sigma_squared/BN_RF*eye(Nr);
                Pilot_tk_UE_index = find(t_k==Pilot_index)';
                for jj = Pilot_tk_UE_index
                    sum_h_kr_LS(:,k) = sum_h_kr_LS(:,k)+sqrt(tau*p(jj))*h_kr_LS_origin(:,jj);
                    if  ismember(jj,FF_UE_Index) %FF-UE
                        dot_Phi_rtk = dot_Phi_rtk+tau*p(jj)*R_kr(:,:,jj);%Eq.(25)
                        sum_h_kr_LS_no_UEk(:,k) = sum_h_kr_LS_no_UEk(:,k)+sqrt(tau*p(jj))*h_kr_LS_origin(:,jj);
                    end
                end
                sigma_tk_squared(k) = dot_Phi_rtk(1,1);
            end
            epsilon = 0.5*(abs(sum_h_kr_LS).^2+repmat(sigma_tk_squared,Nr,1)+abs(sum_h_kr_LS_no_UEk).^2+repmat(sigma_tk_squared,Nr,1));%Size: Nr*K

            %VR detection
            [hat_D_kr,Prob_zero_ana(:,:),Prob_zero_sim(:,:),Prob_one_ana(:,:),Prob_one_sim(:,:)] = VREstimate(VR_FF,D_kr,h_kr_LS,h_kr_NLS,NF_UE_Index,Pilot_index,tau,K,Nr,BN_RF,p,sigma_squared,nbrOfRealization,Pinv_Theta_RF,epsilon,sigma_tk_squared);%Size of hat_D_kr: Nr*nbrOfRealization*K

            %Generate hat_h_kr_LS for NF-UE
            hat_h_kr_LS = h_kr_LS_origin;
            for k = NF_UE_Index
                hat_h_kr_LS(:,k) = hat_D_kr(:,k).*hat_h_kr_LS(:,k);
            end

            %Generate Aggregated CSI
            [g_kl_LS,hat_g_kl_LS,g_kl,hat_g_kl,Brl,bar_A_kl,bar_B_kl,dot_Phi_ltk] = Agg_CSIGenerate(Pilot_index,tau,H_rl,h_kr_LS,hat_h_kr_LS,h_kr_NLS,h_kl,R_kr,R_kl,eta_kr,L,K,Na,Nr,BN_RF,p,sigma_squared,Theta,Pinv_Theta_RF,rho,nbrOfRealization);

            [F_sim,F_ana,varrho_kl_sim,varrho_kl_ana,c_kl_sim,c_kl_ana] = Theorem1(g_kl_LS,hat_g_kl_LS,g_kl,hat_g_kl,R_kr,R_kl,Brl,bar_A_kl,bar_B_kl,dot_Phi_ltk,eta_kr,Pilot_index,tau,K,L,Na,BN_RF,p,sigma_squared,nbrOfRealization);
            fraction = (T-tau)/T;
            [~,R_ana(:,n,ii,l)] = Theorem2(F_sim,F_ana,varrho_kl_sim,varrho_kl_ana,c_kl_sim,c_kl_ana,p,K,fraction);
        end
    end
end
%% Plot simulation results
figureUnits = 'centimeters';
figureWidth = 20;
figureHeight = 8;

figure(1)
hold on; box on;
fp1 = plot(Length,real(sum(R_ana(:,:,1,1),1)),'+-k','LineWidth',2);
fp2 = plot(Length,real(sum(R_ana(:,:,2,1),1)),'o--k','LineWidth',2);

fp3 = plot(Length,real(sum(R_ana(:,:,1,2),1)),'+-b','LineWidth',2);
fp4 = plot(Length,real(sum(R_ana(:,:,2,2),1)),'o--b','LineWidth',2);

fp5 = plot(Length,real(sum(R_ana(:,:,1,3),1)),'+-','Color','#D00000','LineWidth',2);
fp6 = plot(Length,real(sum(R_ana(:,:,2,3),1)),'o--','Color','#D00000','LineWidth',2);



xlabel('Length of cell [m]');
ylabel('Sum SE [bit/s/Hz]');
legend([fp1 fp2 fp3 fp4 fp5 fp6],{'CF-mMIMO ({\it{N}}_{total}=75)','mMIMO ({\it{N}}_{total}=75)','CF-mMIMO ({\it{N}}_{total}=108)','mMIMO ({\it{N}}_{total}=108)','CF-mMIMO ({\it{N}}_{total}=147)','mMIMO ({\it{N}}_{total}=147)'});
set(gcf,'Units',figureUnits,'Position',[0 0 figureWidth figureHeight],'Color','w');