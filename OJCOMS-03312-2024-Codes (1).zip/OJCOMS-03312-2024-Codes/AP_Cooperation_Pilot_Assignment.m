function [Pilot_index,AP_UE_selection,bar_beta_kl,p] = AP_Cooperation_Pilot_Assignment(nu,epsilon,tau,H_rl,h_kr_LS,beta_kr,R_kr,R_kl,L,K,NF_UE_points,FF_UE_points,FF_UE_Index,Na,p,Theta,rho)
%INPUT:
%h_kr_LS           = Channel from UE to RIS; size: Nr*K;
%h_kr_NLS          = Channel from UE to RIS; size: Nr*nbrOfRealization*K;
%h_kl              = Channel from UE to AP; size: Na*nbrOfRealization*L*K;
%R_kr              = Covariance matrix from UE to RIS; Size: Nr*Nr*K;
%R_kl              = Covariance matrix from UE to AP; Size: Na*Na*L*K;

%Prepare to save results

bar_beta_kl = zeros(L,K);
AP_UE_selection = zeros(L,K);
%% Generate basic parameters
for k = 1:K
    for l = 1:L
        Brl = rho*H_rl(:,:,l)*Theta;
        g_kl_LS = Brl*h_kr_LS(:,k);
        bar_beta_kl(l,k) = trace(g_kl_LS*g_kl_LS'+R_kl(:,:,l,k)+Brl*R_kr(:,:,k)*Brl')/Na;
    end
end

M=4;
%Set epsilon for when a non-master AP decides to serve a UE

Pilot_index = zeros(K,1);
masterAPs = zeros(K,1);

for m=1:M
    for k=1:K
        %Determine the master AP for UE k by looking for AP with best channel condition
        [~,master] = max(bar_beta_kl(:,k));
        %p(k)=p(k)/db2pow(b-noiseVariancedBm);
        AP_UE_selection(master,k) = 1;
        masterAPs(k) = master;
        %Assign orthogonal pilots to the first tau UEs
        if k <= tau
            Pilot_index(k) = k;
        else %Assign pilot for remaining UEs
            %Compute received power from to the master AP from each pilot
            pilotinterference = zeros(tau,1);
            for t_k = 1:tau
                pilotinterference(t_k) = sum(p(Pilot_index(1:k-1)==t_k).*bar_beta_kl(master,Pilot_index(1:k-1)==t_k));
            end
            %Find the pilot with the least receiver power
            [~,bestpilot] = min(pilotinterference);
            Pilot_index(k) = bestpilot;
        end
    end
    %Each AP serves the UE with the strongest channel condition on each of
    %the pilots where the AP isn't_k the master AP, but only if its channel
    %is not too weak compared to the master AP
    for l = 1:L
        for t_k = 1:tau
            Pilot_tk_UE_index = find(t_k==Pilot_index);
            if sum(AP_UE_selection(l,Pilot_tk_UE_index)) == 0 %If the AP is not a master AP
                %Find the UE with pilot t_k with the best channel
                [~,UEindex] = max(bar_beta_kl(l,Pilot_tk_UE_index).*p(Pilot_tk_UE_index));
                %Serve this UE if the channel is at most "epsilon" weaker
                %than the master AP's channel
                if abs(bar_beta_kl(l,Pilot_tk_UE_index(UEindex))/bar_beta_kl(masterAPs(Pilot_tk_UE_index(UEindex)),Pilot_tk_UE_index(UEindex))) >= epsilon
                    AP_UE_selection(l,Pilot_tk_UE_index(UEindex)) = 1;
                end
            end
        end
    end
    %power control
    for u=1:K
        sum1(u)=0;
        for l=find(AP_UE_selection(:,u)==1)'
            sum1(u)=sum1(u)+db2pow(bar_beta_kl(l,u));
        end
    end
    eta=min(sum1.^nu);
    for u=1:K
        p(u)=100*eta/(sum1(u))^nu;%rho_da=0.009497;
    end
    %%%
    if m<M
        Pilot_index = zeros(K,1);
        AP_UE_selection = zeros(L,K);
    end
end