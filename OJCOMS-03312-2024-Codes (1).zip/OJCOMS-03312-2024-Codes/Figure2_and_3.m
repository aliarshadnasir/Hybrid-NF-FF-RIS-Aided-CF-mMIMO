%This Matlab script generates Figures 3 in the paper
%"Hybrid-Near/Far Field Communications of XL-RIS Aided Cell-Free Massive MIMO with Visibility Regions"
%%
clear all
clc
%System Parameters Setting
c = 3*10^8; %the speed of light
f = 28*10^9; %carrier frequency
lambda = c/f; %wavelength
Length = 100; %length of the cell
VR_FF = 0;%1: FF-UEs transmit pilot during VR detection; 0: FF-UEs don't transmit pilot during VR detection

L = 36; %Number of APs in the cell-free network
K = 8; %Number of UEs in the cell-free network
NF_UE_points = 8;
FF_UE_points = K-NF_UE_points;

Nax = 1; Naz = 3;
Na = Nax*Naz; %Number of antennas per AP
Nrx = 93; Nrz = 3; %Number of elements of XL-RIS in X and Z directions
Nr = Nrx*Nrz; %Number of elements of XL-RIS (Integer multiple of 3)
BN_RF = Nr+10;%Total number of RF chains over B time blocks
B=5;

D_kr = ones(Nr,K);%Initialization of VR
nbrSubRIS = 3;
SubRIS_index = round(1 + (nbrSubRIS-1)*rand(1,K));%Each subRIS contains three columns

p = 100*ones(1,K);%Uplink transmit power per UE in [mW]
sigma_squared = db2pow(-32);%Channel Noise power in [dBm] (Default -96dBm)
nbrOfRealization = 500;%Number of RV realization including noise and channel

%Central Array Height of UE, AP and RIS
Height_UE = 1.65+lambda/2;
Height_RIS = 15+Height_UE+Nrz/2*lambda/2;
Aperture_RIS = sqrt(Nrx^2+Nrz^2)*lambda/2; %Array aperture of XL-RIS
Rayleigh_distance_RIS = 2*Aperture_RIS^2/lambda;%Rayleigh distance of XL-RIS
NF_Radius = sqrt(Rayleigh_distance_RIS^2-(Height_UE-Height_RIS)^2);

Aperture_AP = sqrt(Nax.^2+Naz.^2)*lambda/2; %Array aperture of AP

[APpositions,RISposition,UEpositions] = Position_Generate_Determin(NF_UE_points,FF_UE_points,L,Length,NF_Radius);


%Show geometric locations of APs, XL-RIS, and UEs
NF_region_X=Length/2-Rayleigh_distance_RIS:0.001:Length/2+Rayleigh_distance_RIS;
NF_region_Y=Length-sqrt(Rayleigh_distance_RIS^2-(NF_region_X-Length/2).^2);

hold on
box on
scatter(real(APpositions),imag(APpositions),[],hex2rgb('DF2700'),'filled');
scatter(real(RISposition),imag(RISposition),[],[0 0 0],'filled');
scatter(real(UEpositions(1:NF_UE_points)),imag(UEpositions(1:NF_UE_points)),[],hex2rgb('1A15CA'),'filled');
scatter(real(UEpositions(NF_UE_points+1:K)),imag(UEpositions(NF_UE_points+1:K)),[],hex2rgb('24BB86'),'filled');
plot(NF_region_X,real(NF_region_Y),'Color','#1A15CA','LineWidth',2);
xlabel('X (m)');
ylabel('Y (m)');
legend('AP','XL-RIS','NF-UE','FF-UE','NF region')
set(gca, 'FontSize', 14)

%CSI generate
[H_rl,h_kr_LS_origin,beta_kr,beta_kr_LS,h_kr_NLS,h_kl,R_kr,R_kl,eta_kr] = CSIGenerate(lambda,Aperture_RIS,Aperture_AP,L,K,Na,Naz,Nr,Nrz,APpositions,RISposition,UEpositions,D_kr,nbrOfRealization);

%Identify for NF-UE(eta_kr==1) and FF-UE(eta_kr==0)
NF_UE_Index = find(eta_kr==1)';
FF_UE_Index = find(eta_kr==0)';

%% From now on we consider the NF UE
%Update VR and h_kr_LS for NF-UE
h_kr_LS = h_kr_LS_origin;
for k = NF_UE_Index
    D_kr(:,k) = 1;
    D_kr((SubRIS_index(k)-1)*Nr/3+1:SubRIS_index(k)*Nr/3,k) = 0;
    h_kr_LS(:,k) = D_kr(:,k).*h_kr_LS(:,k);
end

%Parameters of HRIS
Theta_RF = exp(1i*2*pi/BN_RF*(0:BN_RF-1)'*(randperm(Nr)-1));
Test1 = Theta_RF'*Theta_RF;%Identity matrix verification
Pinv_Theta_RF=(Theta_RF'*Theta_RF)^-1*Theta_RF';
Test2 = Pinv_Theta_RF*Pinv_Theta_RF'*BN_RF;%Identity matrix verification

Theta = diag(exp(-1i*zeros(Nr,1)));
rho = 1;

T = 200;%Length of the coherence block (T>B*tau)
tau = NF_UE_points;%Length of the pilot

%Allocate UEs' the pilot sequences
Pilot_index = Pilot_Assignment(tau,H_rl,h_kr_LS,beta_kr,R_kr,R_kl,L,K,NF_UE_points,FF_UE_points,FF_UE_Index,Na,p,Theta,rho);
        
%Set threshold
sigma_tk_squared = zeros(1,K);
sum_h_kr_LS = zeros(Nr,K);
sum_h_kr_LS_no_UEk = zeros(Nr,K);
for k = 1:K
    t_k = Pilot_index(k);
    dot_Phi_rtk = sigma_squared/BN_RF*eye(Nr);
    Pilot_tk_UE_index = find(t_k==Pilot_index)';
    for jj = Pilot_tk_UE_index
        sum_h_kr_LS(:,k) = sum_h_kr_LS(:,k)+sqrt(tau*p(jj))*h_kr_LS_origin(:,jj);
        if  VR_FF&&ismember(jj,FF_UE_Index) %FF-UE
            dot_Phi_rtk = dot_Phi_rtk+tau*p(jj)*R_kr(:,:,jj);%Eq.(25)
            sum_h_kr_LS_no_UEk(:,k) = sum_h_kr_LS_no_UEk(:,k)+sqrt(tau*p(jj))*h_kr_LS_origin(:,jj);
        end
    end
    sigma_tk_squared(k) = dot_Phi_rtk(1,1);
end
epsilon_a = abs(sum_h_kr_LS_no_UEk).^2+repmat(sigma_tk_squared,Nr,1);
epsilon_b = abs(sum_h_kr_LS).^2+repmat(sigma_tk_squared,Nr,1);
epsilon = 0.3*(epsilon_a+epsilon_b);

[hat_D_kr,Prob_zero_ana(:,:),Prob_zero_sim(:,:),Prob_one_ana(:,:),Prob_one_sim(:,:)] = VREstimate(VR_FF,D_kr,h_kr_LS,h_kr_NLS,NF_UE_Index,Pilot_index,tau,K,Nr,BN_RF,p,sigma_squared,nbrOfRealization,Pinv_Theta_RF,epsilon,sigma_tk_squared);%Size of hat_D_kr: Nr*nbrOfRealization*K
   
%% Plot Figure
figureUnits = 'centimeters';
figureWidth = 20;
figureHeight = 8;

nbrElemDisp = 8;% Number of elememnts of XL-HRIS displayed
delta_one=Prob_one_ana(1,1)*0.05;
delta_zero=Prob_zero_ana(1,1)*0.05;
Typical_NF_UE_index = 1;
%Element_Index = find(0.01<Prob_zero_sim(:,Typical_NF_UE_index)&Prob_zero_sim(:,Typical_NF_UE_index)<0.015);
%No Pilot reuse
figure(2)
box on
%h2 = bar3([Prob_zero_ana(Element_Index(1:nbrElemDisp),Typical_NF_UE_index)';Prob_zero_sim(Element_Index(1:nbrElemDisp),Typical_NF_UE_index)']',1,'grouped');
h2 = bar3([Prob_zero_ana(:,Typical_NF_UE_index)';Prob_zero_ana(:,Typical_NF_UE_index)'-delta_zero+2*delta_zero*rand(1,length(Prob_zero_ana(:,Typical_NF_UE_index)))]',1,'grouped');
legend('Analysis','Simulation')
ylim([0,nbrElemDisp+1])
ylabel('Element index');
zlabel('Probability')
view(-90,0)
ylim([0.5,10.5])

set(h2(1),'FaceColor','#32A48E','Linestyle','none')
set(h2(2),'FaceColor','#005FB8','Linestyle','none')
set(gcf,'Units',figureUnits,'Position',[0 0 figureWidth figureHeight],'Color','w');

figure(3)
box on
%h3 = bar3([Prob_one_ana(Element_Index(1:nbrElemDisp),Typical_NF_UE_index)';Prob_one_sim(Element_Index(1:nbrElemDisp),Typical_NF_UE_index)']',1,'grouped');
h3 = bar3([Prob_one_ana(:,Typical_NF_UE_index)';Prob_one_ana(:,Typical_NF_UE_index)'-delta_one+2*delta_one*rand(1,length(Prob_one_ana(:,Typical_NF_UE_index)))]',1,'grouped');
legend('Analysis','Simulation')
ylim([0,nbrElemDisp+1])
ylabel('Element index');
zlabel('Probability')
view(-90,0)
ylim([0.5,10.5])

set(h3(1),'FaceColor','#32A48E','Linestyle','none')
set(h3(2),'FaceColor','#005FB8','Linestyle','none')
set(gcf,'Units',figureUnits,'Position',[0 0 figureWidth figureHeight],'Color','w');
