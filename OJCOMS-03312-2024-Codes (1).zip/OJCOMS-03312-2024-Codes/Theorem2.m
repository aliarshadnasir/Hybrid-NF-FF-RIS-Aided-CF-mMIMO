function [R_sim,R_ana] = Theorem2(F_sim,F_ana,varrho_kl_sim,varrho_kl_ana,c_kl_sim,c_kl_ana,p,K,fraction)

R_sim = zeros(K,1);
R_ana = zeros(K,1);
for k = 1:K
    C_sim = diag(varrho_kl_sim(:,k))-p(k)*c_kl_sim(:,k)*c_kl_sim(:,k)';
    C_ana = diag(varrho_kl_ana(:,k))-p(k)*c_kl_ana(:,k)*c_kl_ana(:,k)';
    for ii = 1:K
        C_sim = C_sim+p(ii)*F_sim(:,:,k,ii);
        C_ana = C_ana+p(ii)*F_ana(:,:,k,ii);
    end
    R_sim(k) = fraction*log2(1+p(k)*c_kl_sim(:,k)'*C_sim^-1*c_kl_sim(:,k));
    R_ana(k) = fraction*log2(1+p(k)*c_kl_ana(:,k)'*C_ana^-1*c_kl_ana(:,k));
end
