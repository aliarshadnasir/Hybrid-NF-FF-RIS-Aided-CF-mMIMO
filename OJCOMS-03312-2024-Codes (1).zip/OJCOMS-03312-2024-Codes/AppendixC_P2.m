clear all 
clc

N=3;
Nbr=300000;

hat_gkl1_LS=randn(N,1)+1i*randn(N,1);
hat_gkl2_LS=randn(N,1)+1i*randn(N,1);
gil1_LS=randn(N,1)+1i*randn(N,1);
gil2_LS=randn(N,1)+1i*randn(N,1);

Akl1=randn(N,N)+1i*randn(N,N);
Bkl1=randn(N,N)+1i*randn(N,N);
Ajl1=randn(N,N)+1i*randn(N,N);
Bjl1=randn(N,N)+1i*randn(N,N);
Ail1=randn(N,N)+1i*randn(N,N);
Bil1=randn(N,N)+1i*randn(N,N);
Aql1=randn(N,N)+1i*randn(N,N);
Bql1=randn(N,N)+1i*randn(N,N);

Akl2=randn(N,N)+1i*randn(N,N);
Bkl2=randn(N,N)+1i*randn(N,N);
Ajl2=randn(N,N)+1i*randn(N,N);
Bjl2=randn(N,N)+1i*randn(N,N);
Ail2=randn(N,N)+1i*randn(N,N);
Bil2=randn(N,N)+1i*randn(N,N);
Aql2=randn(N,N)+1i*randn(N,N);
Bql2=randn(N,N)+1i*randn(N,N);


wa_kl1=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wa_jl1=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wa_il1=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wa_ql1=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));


wa_kl2=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wa_jl2=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wa_il2=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wa_ql2=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));

wb_kr=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wb_jr=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wb_ir=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wb_qr=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));

bar_gkl1=(Akl1*wa_kl1+Bkl1*wb_kr);
bar_gql1=(Aql1*wa_ql1+Bql1*wb_qr);
bar_gjl1=Ajl1*wa_il1+Bjl1*wb_ir;%i\in{P}_k
gil1=gil1_LS+Ail1*wa_il1+Bil1*wb_ir;
vl1=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));

bar_gkl2=(Akl2*wa_kl2+Bkl2*wb_kr);
bar_gql2=(Aql2*wa_ql2+Bql2*wb_qr);
bar_gjl2=Ajl2*wa_il2+Bjl2*wb_ir;%i\in{P}_k
gil2=gil2_LS+Ail2*wa_il2+Bil2*wb_ir;
vl2=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));


vr=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));


R=0;T1=0;T2=0;T3=0;T4=0;
T5=0;T6=0;
T7=0;
for n=1:Nbr
    R=R+(hat_gkl1_LS+bar_gkl1(:,n)+bar_gjl1(:,n)+bar_gql1(:,n)+vl1(:,n)+vr(:,n))'*gil1(:,n)*gil2(:,n)'*(hat_gkl2_LS+bar_gkl2(:,n)+bar_gjl2(:,n)+bar_gql2(:,n)+vl2(:,n)+vr(:,n))/Nbr;
    T1=T1+hat_gkl1_LS'*gil1(:,n)*gil2(:,n)'*hat_gkl2_LS/Nbr;
    T2=T2+bar_gkl1(:,n)'*gil1(:,n)*gil2(:,n)'*bar_gkl2(:,n)/Nbr;
    T3=T3+bar_gjl1(:,n)'*gil1(:,n)*gil2(:,n)'*bar_gjl2(:,n)/Nbr;
    T4=T4+vr(:,n)'*gil1(:,n)*gil2(:,n)'*vr(:,n)/Nbr;
    T5=T5+hat_gkl1_LS'*gil1(:,n)*gil2(:,n)'*bar_gjl2(:,n)/Nbr;
    T6=T6+bar_gjl1(:,n)'*gil1(:,n)*gil2(:,n)'*hat_gkl2_LS/Nbr;
    T7=T7+bar_gql1(:,n)'*gil1(:,n)*gil2(:,n)'*bar_gql2(:,n)/Nbr;
end
T=T1+T2+T3+T4+T5+T6+T7;