function [g_kl_LS,hat_g_kl_LS,g_kl,hat_g_kl,hat_g_kl2,Brl,bar_A_kl,bar_B_kl,hat_R_kl,hat_R_kr] = Agg_CSIGenerate(Pilot_index,tau,H_rl,h_kr_LS,hat_h_kr_LS,h_kr_NLS,h_kl,R_kr,R_kl,eta_kr,L,K,Na,Nr,BN_RF,p,sigma_squared,Theta,Pinv_Theta_RF,rho,nbrOfRealization)
%INPUT:
%h_kr_LS           = Channel from UE to RIS; size: Nr*K;
%h_kr_NLS          = Channel from UE to RIS; size: Nr*nbrOfRealization*K;
%h_kl              = Channel from UE to AP; size: Na*nbrOfRealization*L*K;
%R_kr              = Covariance matrix from UE to RIS; Size: Nr*Nr*K;
%R_kl              = Covariance matrix from UE to AP; Size: Na*Na*L*K;

%Prepare to save results

g_kl_LS = zeros(Na,L,K);
g_kl_NLS = zeros(Na,nbrOfRealization,L,K);
g_kl = zeros(Na,nbrOfRealization,L,K);

hat_R_kl = zeros(Na,Na,L,K);
hat_R_kr = zeros(Nr,Nr,K);

bar_A_kl = zeros(Na,Na,L,K);
bar_B_kl = zeros(Na,Nr,L,K);
hat_h_kl = zeros(Na,nbrOfRealization,L,K);
hat_g_kl_LS = zeros(Na,L,K);
hat_g_kl_NLS = zeros(Na,nbrOfRealization,L,K);
hat_g_kl = zeros(Na,nbrOfRealization,L,K);

hat_g_kl2 = zeros(Na,nbrOfRealization,L,K);

%% Generate basic parameters

%Generate tilde_h_kr_LS
tilde_h_kr_LS = h_kr_LS-hat_h_kr_LS;
%Generage random noise vectors
nr_tk = sqrt(sigma_squared/2)*(randn(BN_RF,nbrOfRealization,tau)+1i*randn(BN_RF,nbrOfRealization,tau));
nl_tk = sqrt(sigma_squared/2)*(randn(Na,nbrOfRealization,L,tau)+1i*randn(Na,nbrOfRealization,L,tau));
%Generate Brl
Brl = zeros(Na,Nr,L);
for k = 1:K
    for l = 1:L
        Brl(:,:,l) = rho*H_rl(:,:,l)*Theta;
        g_kl_LS(:,l,k) = Brl(:,:,l)*h_kr_LS(:,k);
%         A1 = h_kl(:,:,l,k);
%         A2 = Brl(:,:,l)*h_kr_NLS(:,:,k);
        g_kl_NLS(:,:,l,k) = h_kl(:,:,l,k)+Brl(:,:,l)*h_kr_NLS(:,:,k);
        g_kl(:,:,l,k) = repmat(g_kl_LS(:,l,k),[1,nbrOfRealization])+g_kl_NLS(:,:,l,k);
    end
end

%% Generate the aggregated channel both for the accurate and estiamted version

for k = 1:K
    t_k = Pilot_index(k);
    dot_Phi_rtk = sigma_squared/BN_RF*eye(Nr);
    sum_hjr_NLS = zeros(Nr,1);
    sum_tilde_hjr_LS = zeros(Nr,1);
    sum_tilde_hjr_LS_product = zeros(Nr,Nr);
    Pilot_tk_UE_index = find(t_k==Pilot_index)';
    for jj = Pilot_tk_UE_index
        if eta_kr(jj)==0 %FF-UE
            dot_Phi_rtk = dot_Phi_rtk+tau*p(jj)*R_kr(:,:,jj);%Eq.(25)
            sum_hjr_NLS = sum_hjr_NLS+sqrt(tau*p(jj))*h_kr_NLS(:,:,jj);%Eq.(29d)
        else
            sum_tilde_hjr_LS = sum_tilde_hjr_LS+sqrt(tau*p(jj))*tilde_h_kr_LS(:,jj);%Eq.(29c)
            sum_tilde_hjr_LS_product = sum_tilde_hjr_LS_product+tau*p(jj)*tilde_h_kr_LS(:,jj)*tilde_h_kr_LS(:,jj)';%Eq.(30)
        end
    end
    Phi_rtk = sum_tilde_hjr_LS_product+dot_Phi_rtk;
    hat_R_kr(:,:,k) = tau*p(k)*R_kr(:,:,k)*Phi_rtk^-1*dot_Phi_rtk*Phi_rtk*R_kr(:,:,k);
    
    for l = 1:L
        %Generate hat_h_kl
        Phi_ltk = sigma_squared*eye(Na);
        sum_hjl = nl_tk(:,:,l,t_k);
        for jj = Pilot_tk_UE_index
            Phi_ltk = Phi_ltk+tau*p(jj)*R_kl(:,:,l,jj);%Eq.(18)
            sum_hjl = sum_hjl+sqrt(tau*p(jj))*h_kl(:,:,l,jj);%Eq.(18)
        end
        hat_R_kl(:,:,l,k) = tau*p(k)*R_kl(:,:,l,k)*Phi_ltk^-1*R_kl(:,:,l,k);
        bar_A_kl(:,:,l,k) = sqrt(tau*p(k))*R_kl(:,:,l,k)*Phi_ltk^-1;%Eq.(48)
        hat_h_kl(:,:,l,k) = bar_A_kl(:,:,l,k)*sum_hjl;%Eq.(18)
        %Generate hat_g_kl
        if eta_kr(k)==1 %NF-UE
            hat_g_kl_LS(:,l,k) = Brl(:,:,l)*hat_h_kr_LS(:,k);%Eq.(34)
            hat_g_kl_NLS(:,:,l,k) = hat_h_kl(:,:,l,k);%Eq.(34)
        else %FF-UE
            hat_h_kr_NLS_NF = sqrt(tau*p(k))*R_kr(:,:,k)*Phi_rtk^-1*sum_tilde_hjr_LS;%Eq.(29c)
            hat_g_kl_LS(:,l,k) = Brl(:,:,l)*(h_kr_LS(:,k)+hat_h_kr_NLS_NF);%Eq.(34)

            hat_h_kr_NLS_FF = sqrt(tau*p(k))*R_kr(:,:,k)*Phi_rtk^-1*sum_hjr_NLS;%Eq.(29d)
            hat_h_kr_NLS_N = sqrt(tau*p(k))*R_kr(:,:,k)*Phi_rtk^-1*Pinv_Theta_RF*nr_tk(:,:,t_k);%Eq.(29e)
            hat_g_kl_NLS(:,:,l,k) = hat_h_kl(:,:,l,k)+Brl(:,:,l)*(hat_h_kr_NLS_FF+hat_h_kr_NLS_N);
            
            bar_B_kl(:,:,l,k) = sqrt(tau*p(k))*Brl(:,:,l)*R_kr(:,:,k)*Phi_rtk^-1;%Eq.(48)

        end
        hat_g_kl(:,:,l,k) = repmat(hat_g_kl_LS(:,l,k),[1,nbrOfRealization])+hat_g_kl_NLS(:,:,l,k);
    end
end


% Reexpress the aggregated channel

for k = 1:K
    t_k = Pilot_index(k);
    Pilot_tk_UE_index = find(t_k==Pilot_index)';
    for l = 1:L
        v_rl_tk = bar_A_kl(:,:,l,k)*nl_tk(:,:,l,t_k)+bar_B_kl(:,:,l,k)*Pinv_Theta_RF*nr_tk(:,:,t_k);
        hat_g_kl2(:,:,l,k) = hat_g_kl_LS(:,l,k)+v_rl_tk;
        for jj = Pilot_tk_UE_index
            bar_g_jl_NLS = bar_A_kl(:,:,l,k)*h_kl(:,:,l,jj)+bar_B_kl(:,:,l,k)*h_kr_NLS(:,:,jj);
            hat_g_kl2(:,:,l,k) = hat_g_kl2(:,:,l,k)+sqrt(tau*p(jj))*bar_g_jl_NLS;
            %Test Corollary 1
            i1 = jj;
            Es_case1_sim = trace(abs(bar_g_jl_NLS'*g_kl(:,:,l,i1)).^2)/nbrOfRealization;
            Es_case1_ana = Lemma1(zeros(Na,1),g_kl_LS(:,l,i1),bar_A_kl(:,:,l,k)*R_kl(:,:,l,i1)^0.5,R_kl(:,:,l,i1)^0.5,bar_B_kl(:,:,l,k)*R_kr(:,:,i1)^0.5,Brl(:,:,l)*R_kr(:,:,i1)^0.5);
            i2 = 6;
            Es_case2_sim = trace(abs(bar_g_jl_NLS'*g_kl(:,:,l,i2)).^2)/nbrOfRealization;
            Es_case2_ana = trace((g_kl_LS(:,l,i2)*g_kl_LS(:,l,i2)'+R_kl(:,:,l,i2)+Brl(:,:,l)*R_kr(:,:,i2)*Brl(:,:,l)')*(bar_A_kl(:,:,l,k)*R_kl(:,:,l,jj)*bar_A_kl(:,:,l,k)'+bar_B_kl(:,:,l,k)*R_kr(:,:,jj)*bar_B_kl(:,:,l,k)'));
            %Test Corollary 2
            l2 = 6;
            bar_g_jl2_NLS = bar_A_kl(:,:,l2,k)*h_kl(:,:,l2,jj)+bar_B_kl(:,:,l2,k)*h_kr_NLS(:,:,jj);
            Ec_case1_sim = trace((bar_g_jl_NLS'*g_kl(:,:,l,i1)).*(g_kl(:,:,l2,i1)'*bar_g_jl2_NLS))/nbrOfRealization;
            S11l1 = bar_A_kl(:,:,l,k)*R_kl(:,:,l,i1)^0.5;
            S21l1 = R_kl(:,:,l,i1)^0.5;
            S12l1 = bar_B_kl(:,:,l,k)*R_kr(:,:,i1)^0.5;
            S22l1 = Brl(:,:,l)*R_kr(:,:,i1)^0.5;
            S11l2 = bar_A_kl(:,:,l2,k)*R_kl(:,:,l2,i1)^0.5;
            S21l2 = R_kl(:,:,l2,i1)^0.5;
            S12l2 = bar_B_kl(:,:,l2,k)*R_kr(:,:,i1)^0.5;
            S22l2 = Brl(:,:,l2)*R_kr(:,:,i1)^0.5;
            Ec_case1_ana = Lemma2(zeros(Na,1),g_kl_LS(:,l,i1),zeros(Na,1),g_kl_LS(:,l2,i1),S11l1,S21l1,S12l1,S22l1,S11l2,S21l2,S12l2,S22l2);
            %
            Ec_case2_sim = trace((bar_g_jl_NLS'*g_kl(:,:,l,i2)).*(g_kl(:,:,l2,i2)'*bar_g_jl2_NLS))/nbrOfRealization;
            Ec_case2_ana = trace((g_kl_LS(:,l,i2)*g_kl_LS(:,l2,i2)'+Brl(:,:,l)*R_kr(:,:,i2)*Brl(:,:,l2)')*bar_B_kl(:,:,l2,k)*R_kr(:,:,jj)*bar_B_kl(:,:,l,k)');
        end
    end
end










