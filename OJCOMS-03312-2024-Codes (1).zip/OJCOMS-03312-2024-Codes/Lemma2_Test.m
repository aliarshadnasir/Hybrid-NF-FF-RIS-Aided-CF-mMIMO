clear all 
clc

N=4;
Nbr=100000;
S11l1=randn(N,N)+1i*randn(N,N);
S12l1=randn(N,N)+1i*randn(N,N);
S21l1=randn(N,N)+1i*randn(N,N);
S22l1=randn(N,N)+1i*randn(N,N);

S11l2=randn(N,N)+1i*randn(N,N);
S12l2=randn(N,N)+1i*randn(N,N);
S21l2=randn(N,N)+1i*randn(N,N);
S22l2=randn(N,N)+1i*randn(N,N);

u1l1=(randn(N,1)+1i*randn(N,1));
u2l1=(randn(N,1)+1i*randn(N,1));
u1l2=(randn(N,1)+1i*randn(N,1));
u2l2=(randn(N,1)+1i*randn(N,1));

wl1=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
wl2=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));
w=sqrt(0.5)*(randn(N,Nbr)+1i*randn(N,Nbr));

g1l1=u1l1+S11l1*wl1+S12l1*w;
g2l1=u2l1+S21l1*wl1+S22l1*w;
g1l2=u1l2+S11l2*wl2+S12l2*w;
g2l2=u2l2+S21l2*wl2+S22l2*w;

R1=0;T1=0;T1A=0;T1B=0;T2=0;T3=0;T4=0;T5=0;T6=0;
for n=1:Nbr
    R1=R1+g1l1(:,n)'*g2l1(:,n)*g2l2(:,n)'*g1l2(:,n)/Nbr;
end


EX1 = (u1l1'*u2l1+trace(S11l1'*S21l1)+trace(S12l1'*S22l1))*(u2l2'*u1l2+trace(S21l2'*S11l2)+trace(S22l2'*S12l2));
EX2 = trace(S12l1'*S22l1*S22l2'*S12l2);
EX3 = trace(u1l2*u1l1'*S22l1*S22l2'+u2l1*u2l2'*S12l2*S12l1');

R2 = EX1+EX2+EX3;