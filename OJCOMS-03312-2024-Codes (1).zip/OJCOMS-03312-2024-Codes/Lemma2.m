function Ec = Lemma2(u1l1,u2l1,u1l2,u2l2,S11l1,S21l1,S12l1,S22l1,S11l2,S21l2,S12l2,S22l2)

EX1 = (u1l1'*u2l1+trace(S11l1'*S21l1)+trace(S12l1'*S22l1))*(u2l2'*u1l2+trace(S21l2'*S11l2)+trace(S22l2'*S12l2));
EX2 = trace(S12l1'*S22l1*S22l2'*S12l2);
EX3 = trace(u1l2*u1l1'*S22l1*S22l2'+u2l1*u2l2'*S12l2*S12l1');

Ec = EX1+EX2+EX3;
