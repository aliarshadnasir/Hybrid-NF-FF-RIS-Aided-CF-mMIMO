function [H_BR, h_RU, h_BU] = channel_data(K_max,Nr_max,Nt_max,N_max,N_max_vec,Nt_max_vec,Nr_max_vec,Nx,KR_BR,KR_RU,simulations_max,scen)

% h_BU needed only for direct path which is not assumed in scenario 2 that is considered in RIS PLS paper

% K_max = 20; Nt_max = 24; N_max = 400; M_max = 256; simulations_max = 100;
% N_max_vec = [0:N_max-1]'; Nt_max_vec = [0:Nt_max-1]'; Nx = 10; KR_BR = 10^(5/10); KR_RU = 10^(0/10);



%%%% NLoS components of channel
% clc; clear; 
% K_max = 20; Nt_max = 24; N_max = 400; M_max = 256; simulations_max = 100; Nr_max = 8;
% h_BR_NLoS_store = 1/sqrt(2) * (randn(N_max,Nt_max,simulations_max) + 1j*randn(N_max,Nt_max));
% h_RU_NLoS_store = 1/sqrt(2) * (randn(Nr_max,N_max,K_max,simulations_max) + 1j*randn(Nr_max,N_max,K_max,simulations_max));
% h_BU_NLoS_store = 1/sqrt(2) * (randn(Nr_max,Nt_max,K_max,simulations_max) + 1j*randn(Nr_max,Nt_max,K_max,simulations_max));
% save chan_RIS_Cap.mat h_BR_NLoS_store h_BU_NLoS_store h_RU_NLoS_store;
%%%%
load chan_RIS_Cap.mat;

BS = [20 0 25];
RIS = [0 30 40];

% UE_dist_range = 60;
% % UEs are distributed on the right side of the point RIS(2)
% % UEs are distributed in the area (UE_dist_range x UE_dist_range) on the RHS of RIS
% UE_store = [UE_dist_range*rand(K_max,1) (RIS(2)+ UE_dist_range*rand(K_max,1)) 1.5*ones(K_max,1)];
% save UE_store_60_60_RIS_y_60.mat;

load UE_store_60_60_RIS_y_60.mat;
UE = UE_store(1:K_max,:);
if (scen == 1)
    UE(:,1:2) = UE(:,1:2)*2;
end

% scatter(RIS(1),RIS(2),80,'d','k');
% hold on;
% scatter(BS(1), BS(2),80,'d','b');
% for k = 1:K_max
%     scatter(UE(k,1), UE(k,2),80,'d','g');
% end

theta_BR_A = atan((RIS(2)-BS(2))/(BS(1)-RIS(1)));
theta_BR_D = pi/2 - theta_BR_A;
phi_BR_A = atan( -(RIS(3)-BS(3)) / pdist2(BS(1:2),RIS(1:2)) );

theta_RU_A = zeros(K_max,1); phi_RU_D = zeros(K_max,1);
for k=1:K_max
    theta_RU_A(k) = atan( abs(UE(k,2)-RIS(2)) / (UE(k,1)-RIS(1)) );
    phi_RU_D(k) = atan( -(RIS(3)-UE(k,3)) / pdist2(RIS(1:2),UE(k,1:2)) );
end
theta_RU_D = pi/2 - theta_RU_A;
GBS = 5; GRS = 5; % dBi

PL_BR = GBS + GRS - 35.9 - 22*log10(pdist2(RIS,BS)); % dB
PL_RU = GRS - 33.05 - 30*log10(pdist2(RIS,UE)); % dB
PL_BU = GBS - 33.05 - 36.7*log10(pdist2(BS,UE)); % dB

beta_BR = 10.^(PL_BR/10); beta_RU = 10.^(PL_RU/10); beta_BU = 10.^(PL_BU/10);

aR_BR = exp(1j*pi*( floor(N_max_vec/Nx)*sin(phi_BR_A)*sin(theta_BR_A) + (N_max_vec-floor(N_max_vec/Nx)*Nx)*sin(phi_BR_A)*cos(theta_BR_A)  ));
aB_BR = exp(1j*pi*Nt_max_vec*sin(theta_BR_D));
aR_RU = zeros(N_max,K_max);
aU_RU = zeros(Nr_max,K_max);
for k = 1:K_max
    aR_RU(:,k) = exp(1j*pi*( floor(N_max_vec/Nx)*sin(phi_RU_D(k))*sin(theta_RU_D(k)) + (N_max_vec-floor(N_max_vec/Nx)*Nx)*sin(phi_RU_D(k))*cos(theta_RU_D(k))  ));
    aU_RU(:,k) = exp(1j*pi*Nr_max_vec*sin(theta_RU_A(k)));
end


H_BR = zeros(N_max,Nt_max,simulations_max);
h_BU = zeros(Nr_max,Nt_max,K_max,simulations_max);
h_RU = zeros(Nr_max,N_max,K_max,simulations_max);

for sim = 1:simulations_max
    
    %%% BS-RIS channel
   
    h_BR_NLoS = h_BR_NLoS_store(1:N_max,1:Nt_max,sim);
    h_BR_LoS = aR_BR*aB_BR';
    H_BR(:,:,sim) = sqrt(beta_BR)*( sqrt(KR_BR/(KR_BR+1))*h_BR_LoS + sqrt(KR_BR/(KR_BR+1))*h_BR_NLoS );

    %%% BS-UE channel

    h_BU_NLoS =  h_BU_NLoS_store(1:Nr_max,1:Nt_max,1:K_max,sim);
    for k = 1:K_max
        h_BU(:,:,k,sim) = sqrt(beta_BU(k)) * h_BU_NLoS(:,:,k);
    end
    
    %%% RIS-UE channel


    h_RU_NLoS = h_RU_NLoS_store(1:Nr_max,1:N_max,1:K_max,sim);
    for k = 1:K_max
        h_RU_LoS = aU_RU(:,k)*aR_RU(:,k)';
        h_RU(:,:,k,sim) = sqrt(beta_RU(k)) * ( sqrt(KR_RU/(KR_RU+1))*h_RU_LoS + sqrt(KR_RU/(KR_RU+1))*h_RU_NLoS(:,:,k) );
    end
    
end


