function [APpositions,RISposition,UEpositions] = Position_Generate(NF_UE_points,FF_UE_points,L,Length,NF_Radius)

%Deploy APs,XL-RIS, and UEs on the grid
nbrAPsPerDim = sqrt(L);%Number of APs per dimension on the grid
interAPDistance = Length/nbrAPsPerDim;%Distance between APs in vertical/horizontal direction
AP_locationsGridHorizontal = repmat(interAPDistance/2:interAPDistance:Length-interAPDistance/2,[nbrAPsPerDim 1]);
AP_locationsGridVertical = AP_locationsGridHorizontal';
APpositions = AP_locationsGridHorizontal(:) + 1i*AP_locationsGridVertical(:);%size; L*1
RISposition = Length/2+1i*Length;


RISposition_X=real(RISposition); RISposition_Y=imag(RISposition); %centre of disk
r_small=0.01;
uniRV = unifrnd(1,(NF_Radius/r_small)^2,NF_UE_points,1);
theta = pi+pi*rand(NF_UE_points,1);
NF_UEpositions_X = r_small*sqrt(uniRV).*cos(theta)+RISposition_X;
NF_UEpositions_Y = r_small*sqrt(uniRV).*sin(theta)+RISposition_Y;
NF_UEpositions = NF_UEpositions_X+1i*NF_UEpositions_Y;

FF_UEpositions_X = Length*rand(FF_UE_points,1);
FF_UEpositions_Y = (Length-NF_Radius)*rand(FF_UE_points,1);
FF_UEpositions = FF_UEpositions_X+1i*FF_UEpositions_Y;

UEpositions = [NF_UEpositions;FF_UEpositions];
