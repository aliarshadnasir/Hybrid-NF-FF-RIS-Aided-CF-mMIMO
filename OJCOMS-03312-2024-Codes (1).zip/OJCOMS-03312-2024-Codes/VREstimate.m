function [hat_D_kr,Prob_zero_ana,Prob_zero_sim,Prob_one_ana,Prob_one_sim] = VREstimate(VR_FF,D_kr,h_kr_LS,h_kr_NLS,NF_UE_Index,Pilot_index,tau,K,Nr,BN_RF,p,sigma_squared,nbrOfRealization,Pinv_Theta_RF,epsilon,sigma_tk_squared)
%INPUT:
%Nr                = Number of elements of RIS
%h_kr_LS           = Channel from UE to RIS; size: Nr*K
%D_kr              = Realistic VR of UEs; size: Nr*K
%OUTPUT:
%hat_D_kr          = Estimated VR of UEs; size: Nr*K
%% Generate basic parameters

%Generate h_kr
h_kr = zeros(Nr,nbrOfRealization,K);
for  k = 1:K
     h_kr(:,:,k) = repmat(h_kr_LS(:,k),[1,nbrOfRealization])+h_kr_NLS(:,:,k);
end
%Generate nr_tk
nr_tk = sqrt(sigma_squared/2)*(randn(BN_RF,nbrOfRealization,tau)+1i*randn(BN_RF,nbrOfRealization,tau));

%% Prepare to save results

%Initialization of the estimated VR
hat_D_kr_ergodic = ones(Nr,nbrOfRealization,K);
hat_D_kr = ones(Nr,K);

%Initialization of Miss Detection Probability (Wrontly estimated as zero) 
N0 = sum(D_kr(:,NF_UE_Index(1)));
N1 = Nr-N0;
Prob_zero_ana = zeros(N0,length(NF_UE_Index));
Prob_zero_sim = zeros(N0,length(NF_UE_Index));

%Initialization of False Alarm Probability (Wrontly estimated as one) 
Prob_one_ana = zeros(N1,length(NF_UE_Index));
Prob_one_sim = zeros(N1,length(NF_UE_Index));

Length_zero = zeros(1,length(NF_UE_Index));
Length_one = zeros(1,length(NF_UE_Index));

for k = NF_UE_Index%Note: NF-UE only has the LoS path concering RIS
    %z_rtk = sqrt(tau*p(k))*repmat(h_kr_LS(:,k),[1,nbrOfRealization])+Pinv_Theta_RF*nr_tk(:,:,Pilot_index(k));%Received pilot signal of RIS; Eq.(25)
    z_rtk = Pinv_Theta_RF*nr_tk(:,:,Pilot_index(k));
    t_k = Pilot_index(k);
    Pilot_tk_UE_index = find(t_k==Pilot_index)';
    for jj = Pilot_tk_UE_index
        if VR_FF == 1
            z_rtk = z_rtk+sqrt(tau*p(jj))*h_kr(:,:,jj);
        elseif ismember(jj,NF_UE_Index)
            z_rtk = z_rtk+sqrt(tau*p(jj))*h_kr(:,:,jj);
        end
    end

    hat_D_kr_ergodic(:,:,k) = ~(abs(z_rtk).^2<epsilon(:,k));
    
    Index1 = find(D_kr(:,k) == 1);
    Length_zero(k) = length(Index1);
    Index0 = find(D_kr(:,k) == 0);
    Length_one(k) = length(Index0);
    %u_kn_squared1 = tau*p(k)*abs(h_kr_LS(Index1,k)).^2;
    u_kn1 = zeros(length(Index1),1);
    u_kn0 = zeros(length(Index0),1);
    for jj = Pilot_tk_UE_index
        if VR_FF == 1
            u_kn1 = u_kn1+sqrt(tau*p(jj))*h_kr_LS(Index1,jj);
            u_kn0 = u_kn0+sqrt(tau*p(jj))*h_kr_LS(Index0,jj);
        elseif ismember(jj,NF_UE_Index)
            u_kn1 = u_kn1+sqrt(tau*p(jj))*h_kr_LS(Index1,jj);
            u_kn0 = u_kn0+sqrt(tau*p(jj))*h_kr_LS(Index0,jj);
        end
    end
    u_kn_squared1 = abs(u_kn1).^2;
    u_kn_squared0 = abs(u_kn0).^2;

    Prob_zero_ana(:,k) = 1-marcumq(sqrt(u_kn_squared1/(sigma_tk_squared(k)/2)),sqrt(epsilon(Index1,k)/(sigma_tk_squared(k)/2)));
    Prob_zero_sim(:,k) = sum(abs(z_rtk(Index1,:)).^2<epsilon(Index1,k),2)/nbrOfRealization;
    %Prob_one_ana(Index0,k) = exp(-epsilon(k)/sigma_tk_squared(k));
    Prob_one_ana(:,k) = marcumq(sqrt(u_kn_squared0/(sigma_tk_squared(k)/2)),sqrt(epsilon(Index0,k)/(sigma_tk_squared(k)/2)));
    Prob_one_sim(:,k) = sum(abs(z_rtk(Index0,:)).^2>=epsilon(Index0,k),2)/nbrOfRealization;
end

%Generate hat_D_kr from hat_D_kr_ergodic
for k = 1:K
    hat_D_kr(:,k) = hat_D_kr_ergodic(:,1,k);
end
